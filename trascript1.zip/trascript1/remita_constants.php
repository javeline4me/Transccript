<?php
//@company - SystemSpecs
//@product - Remita
//@author - Oshadami Mike
/*
define("MERCHANTID", "550854200");
define("SERVICETYPEID", "550907894");
define("APIKEY", "084597");
define("GATEWAYURL", "https://login.remita.net/remita/ecomm/split/init.reg");
define("GATEWAYRRRPAYMENTURL", "https://login.remita.net/remita/ecomm/finalize.reg");
define("CHECKSTATUSURL", "https://login.remita.net/remita/ecomm");
*/

define("MERCHANTID", "550854200");
define("SERVICETYPEID", "550907894");
define("APIKEY", "084597");
define("GATEWAYURL", "https://login.remita.net/remita/ecomm/split/init.reg");
define("GATEWAYRRRPAYMENTURL", "https://login.remita.net/remita/ecomm/finalize.reg");
define("CHECKSTATUSURL", "https://login.remita.net/remita/ecomm");
//define("PATH", 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']));
 
?>