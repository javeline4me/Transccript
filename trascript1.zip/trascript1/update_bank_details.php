<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

$fetchget =  mysqli_query($con,"select *  from company_account WHERE accountNo = '".$_GET['id']."' AND bankStatus = 1 ");
$getrecord = mysqli_fetch_assoc($fetchget);
$bnkname = !empty($getrecord['BankName'])?$getrecord['BankName']:"";
$accountno = !empty($getrecord['accountNo'])?$getrecord['accountNo']:"";
$ccountName = !empty($getrecord['AccountName'])?$getrecord['AccountName']:"";

if(isset($_POST['update']))
		  {
			$bankname = $_POST['bankname'];
			$accountname = $_POST['accountname'];
			$accountno = $_POST['accountno'];
		   mysqli_query($con,"update company_account set  accountNo ='$accountno',BankName='$bankname',AccountName ='$accountname' WHERE accountNo = '".$_GET['id']."'");
		   
		   header("Location:reatebank_details.php");
		   $msg = "Updated Successfully";
			
                  $_SESSION['updatemsg']= $msg;
		  }
?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Add Bank</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Add Bank</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">
									
									<div class="row margin-top-30">
										<div class="col-lg-6 col-md-12">
											<div class="panel panel-white">
											<!--
												<div class="panel-heading">
													<h5 class="panel-title">Setup Type</h5>
												</div>
												-->
												<div class="panel-body">
								<p style="color:red;"><?php echo htmlentities($_SESSION['msg']);?>
								<?php echo htmlentities($_SESSION['msg']="");?></p>	
													<form role="form" name="dcotorspcl" method="post" >
														<div class="form-group">
															<label for="exampleInputEmail1">
																Bank Name
															</label>
							<input type="text" name="bankname" class="form-control"  placeholder="Enter Bank Name" value = "<?php echo $bnkname ?>" >
														</div>
														<div class="form-group">
															<label for="exampleInputEmail1">
																Account Name
															</label>
							<input type="text" name="accountname" class="form-control"  placeholder="Enter Account Name" value = "<?php echo $ccountName ?>" >
														</div>
														<div class="form-group">
															<label for="exampleInputEmail1">
																Account No
															</label>
							<input type="text" name="accountno" class="form-control"  placeholder="Enter Account Number" value = "<?php echo $accountno ?>" >
														</div>
												
														
														<button type="submit" name="update" class="btn btn-o btn-primary">
															Update
														</button>
													</form>
												</div>
											</div>
										</div>
											
											</div>
										</div>
									<div class="col-lg-12 col-md-12">
											<div class="panel panel-white">
												
												
											</div>
										</div>
									</div>

									
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
