<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login2();
 $userid = $_SESSION['id'];

$sql2 = mysqli_query($con,"select * from alumni_account WHERE StudentNumber='$userid'");
$data = mysqli_fetch_array($sql2);
$phonenumber = $data['PhoneNumber'];
$emailaddress = $data['Email'];
$username = $data['StudentNumber'];
$fullnames = $data['FullName'];
$checksq3 = mysqli_query($con,"select * from request_transcript   where StudentNumber = '$username' AND  ReceivedStatus = '0' AND SendStatus ='0' AND ClosedStatus = '0' ");
//$userID = $data['id'];

if(isset($_POST['submit']))
{
	$transactiondatetime = date("Y-m-d h:i:sa");
	
	$converteddate = date("Y-m-d h:i:s");
	$trandatedate = date("Y-m-d");
	$timetransact = date("h:i:s");
	$milliseconds =  strtotime($converteddate);
	$autotransID = mt_rand();
	$transactioncode = $autotransID."-".$milliseconds;
	
	$pahases = $_POST['pahases'];
	$getphases = explode("/",$pahases);
	$phaseid = $getphases[0];
	$phaseamount = $getphases[1];
	$charges = $getphases[2];
	$amount = $phaseamount + $charges;
	
	$pendingpayment = mysqli_num_rows(mysqli_query($con,"SELECT * FROM transaction_details WHERE userID = '$userid' AND trans_status = 'Pending' AND usedStatus = 'Open' "));
	
	if($pendingpayment<1){
		
	$rowcount = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details WHERE userID = '$userid' AND trans_status = 'Confirmed' AND usedStatus = 'Open' "));
	
	if($rowcount<1){
		$con->begin_transaction(); 
	mysqli_query($con,"INSERT INTO transaction_details_logs(tran_ID,userID,entry_Type,transactionAmount,paymentGateway,RRRStatus
	,RRRMessage,trans_ref_no,phnoneNumber,emailAddrerss,trans_Date_Time,transTime,trans_date,Fullname,trans_status) 
	VALUES('$transactioncode','$userid','$phaseid','$amount','Ramita','','','','$phonenumber','$emailaddress','$transactiondatetime','$timetransact','$trandatedate','$fullnames','0')");
		$con->commit(); 
	header("Location:enrollment2");
	$_SESSION['amount'] = $amount;
	$_SESSION['transid'] = $transactioncode;
	$_SESSION['paytypeid'] = $phaseid;
	
	
	
	}else{
	$msg="Sorry, you have a pendng Application. You can only go ahead to apply please!";	
	}
	
	}else{	
	$msg="Sorry, you have a pendng transaction and cannot start a new transaction please!";		
	}
}

?>

<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar1.php');?>
			<div class="app-content">
				
						<?php include('include/headeralumini.php');?>
						
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">User | Make Payment</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>User </span>
									</li>
									<li class="active">
										<span>Make Payment</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
							<?php
							if(mysqli_num_rows($checksq3)<1){
							}else{
												
	echo '<font style="color:red">SORRY, YOU HAVE MADE PAYMENT AND IS PENDING FOR PROCESSING</font>';
	
	//header("Location:alumni_dashboard");
}
if(mysqli_num_rows($checksq3)<1){
							
							?>
								<!--<div class="col-md-12">-->
<h5 style="color: red; font-size:18px; ">
<?php if($msg) { echo htmlentities($msg);}?> </h5>
									<!--<div class="row margin-top-30">-->
										<div class="col-lg-6 col-md-6">
											<div class="panel panel-white">
												<div class="panel-heading">
													<!--<h5 class="panel-title">Enter Bank Details</h5>-->
												</div>
												<div class="panel-body">
									<?php 
$sql=mysqli_query($con,"select * from alumni_account where StudentNumber='".$_SESSION['id']."'");
$data=mysqli_fetch_array($sql);
//while($data=mysqli_fetch_array($sql))
//{
?>
<h4><?php echo "Payment Details ".$data['StudentNumber']?></h4>
<h4><?php echo htmlentities($data['FullName']);?>'s Profile</h4>
<hr />													<form role="form" name="edit" method="post">
													
													<div class="form-group">
															<label for="DoctorSpecialization">
																Select Phase category
															</label>
							<select name="pahases" class="form-control" required="true">
																<option value="">Select Phase</option>
														<?php $ret=mysqli_query($con,"select * from payment_type where levelStatus = '1' ");
														while($row=mysqli_fetch_array($ret))
														{
														?>
													<option value="<?php echo htmlentities($row['id']."/".$row['entryAmount']."/".$row['chargeamount']);?>">
														<?php echo htmlentities($row['paymentype'])." @ "?><span>&#8358;</span><?php echo number_format(($row['entryAmount']));?>
													</option>
													<?php } ?>
													
												</select>
											</div>
																		</div>
										
										
													<br/>
													<br/>

														
														<button type="submit" name="submit" class="btn btn-o btn-primary">
															Continue
														</button>
													</form>
													<?php } ?>
												</div>
											</div>
										
											<!--
									<div class="col-lg-6 col-md-6">
											<div class="panel panel-white">
												
									<img src="<?php //echo $data['passporturl']; ?>"><br/>
									<br/>
									
										
											<h4><?php //echo htmlentities($data['FullName']);?>'s Profile</h4>	
											</div>
										</div>
										-->
									</div>
								</div>
						
						<!-- end: BASIC EXAMPLE -->
			
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
