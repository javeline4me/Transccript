<?php
		session_start();
		error_reporting(0);
		include("include/config.php");
		$length = 8;
		//$userID = generateRandomString($length);
		if(isset($_POST['submit']))
		{
		//create records
				$StudentNumber=$_POST['studentnumber'];
				$fname=$_POST['full_name'];
				$email=$_POST['email'];
				$phoneno = $_POST['phoneno'];
				$password=md5($_POST['password']);
				$Status = 1;
				$usernames = $_POST['usernames'];
			$query=mysqli_query($con,"insert into alumni_account(StudentNumber,FullName,Email,UserName,PassWord,PhoneNumber,userStatus) values('$StudentNumber','$fname','$email','$usernames','$password','$phoneno','$Status')");	
				
			if($query=1)
			{
			echo "SELECT * FROM alumni_account WHERE UserName='".$_POST['usernames']."' ";
		$ret=mysqli_query($con,"SELECT * FROM alumni_account WHERE UserName='".$_POST['usernames']."' ");
		$num=mysqli_fetch_array($ret);
		if($num>0)
		{
		$extra="alumni_dashboard";//
		$_SESSION['login'] = $_POST['usernames'];
		$_SESSION['id']=$StudentNumber;
		$host=$_SERVER['HTTP_HOST'];
		$uip=$_SERVER['REMOTE_ADDR'];
		$status=1;
		// For stroing log if user login successfull
		$log=mysqli_query($con,"insert into userlog(uid,username,userip,status) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$status')");
		
		$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		
		header("location:http://$host$uri/$extra");
		exit();
		}
		else
		{
			// For stroing log if user login unsuccessfull
		$_SESSION['login']=$_POST['username'];	
		$uip=$_SERVER['REMOTE_ADDR'];
		$status=0;
		mysqli_query($con,"insert into userlog(username,userip,status) values('".$_SESSION['login']."','$uip','$status')");
		$_SESSION['errmsg']="Invalid username or password";
		$extra2="alumnilogin";
		$host  = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		header("location:http://$host$uri/$extra2");
		exit();
		}

			}
		}
?>



<html lang="en">

	<head>
		<title>User Registration</title>
		
		<!--<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />-->
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		
		<script type="text/javascript">
			function valid()
			{
			 if(document.registration.password.value!= document.registration.password_again.value)
			{
			alert("Password and Confirm Password Field do not match  !!");
			document.registration.password_again.focus();
			return false;
			}
			return true;
			}
		</script>
		

	</head>

	<body class="login">
		<!-- start: REGISTRATION -->
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
				<a href="#"><h4>JOSTUM | Membership Registration</h4></a>
				</div>
				<!-- start: REGISTER BOX -->
				<div class="box-register">
					<form name="registration" id="registration"  method="post" onSubmit="return valid();">
						<fieldset>
							<legend>
								Sign Up
							</legend>
							<p>
								Enter your personal details below:
							</p>
							<div class="form-group">
								<input type="text" class="form-control" name="full_name" placeholder="Full Name" required>
							</div>
							<div class="form-group">
								<input type="text" class="form-control" name="studentnumber" placeholder="Student Number" required>
							</div>
				
							<div class="form-group">
								<input type="text" class="form-control" name="phoneno" placeholder="Enter Phone Number" required>
							</div>
							<p>
								Enter your account details below:
							</p>
							<div class="form-group">
								<span class="input-icon">
									<input type="email" class="form-control" name="email" id="email"   placeholder="Enter Email" required>
									<i class="fa fa-envelope"></i> </span>
									 <span id="user-availability-status1" style="font-size:12px;"></span>
							</div>
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" id="usernames" name="usernames" placeholder="Enter UserName" required>
									<i class="fa fa-user"></i> </span>
									<span id="user-availability-status2" style="font-size:12px;"></span>
							</div>
							<div class="form-group">
								<span class="input-icon">
									<input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
									<i class="fa fa-lock"></i> </span>
							</div>
							<div class="form-group">
								<span class="input-icon">
									<input type="password" class="form-control"  id="password_again" name="password_again" placeholder="Password Again" required>
									<i class="fa fa-lock"></i> </span>
							</div>
							
							<div class="form-group">
								<div class="checkbox clip-check check-primary">
									<input type="checkbox" id="agree" value="agree" checked="true" readonly=" true">
									<label for="agree">
										I agree
									</label>
								</div>
							</div>
							<div class="form-actions">
								<p>
									Already have an account?
									<a href="alumnilogin">
										Log-in
									</a>
								</p>
								<button type="submit" class="btn btn-primary pull-right" id="submit" name="submit">
									Submit <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
						</fieldset>
					</form>

					<div class="copyright">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> JOSTUM Alumni</span>. <span>All rights reserved</span>
					</div>

				</div>

			</div>
		</div>
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="assets/js/login.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
		
	<script>
		function userAvailability() {
		$("#loaderIcon").show();
		jQuery.ajax({
		url: "check_memberavailability.php",
		data:'usernames='+$("#usernames").val(),
		type: "POST",
		success:function(data){
		$("#user-availability-status2").html(data);
		$("#loaderIcon").hide();
		},
		error:function (){}
		});
		}
		function checkReferrer(){
		$("#loaderIcon").show();
		jQuery.ajax({
		url: "available_referrer.php",
		data:'referrer='+$("#referrer").val(),
		type: "POST",
		success:function(data){
		$("#user-availability-status3").html(data);
		$("#loaderIcon").hide();
		},
		error:function (){}
		});
		}
	</script>	
		
	</body>
	<!-- end: BODY -->
</html>