<?php 
include('include/config.php');
include('include/checklogin.php');
include('include/transcript.func.php');
//check_login();
session_start();
ob_start();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
	include("include/headerscript.html");
	?>

<body>

<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Members</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Uopload Members</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						<div class="rows">
													<div class="col-md-6">
								
	 
	<?php
	 
	//include "connection.php"; //Connect to Database

	//Upload File
	if (isset($_POST['upload'])) {
	
		$handle = fopen($_FILES['filename']['tmp_name'], "r");
		
		//Import uploaded file to Database
	
	 
	//echo 'nnnnnnn12';
	
	$r=0;
	
	// echo 'nnnnnnn13';
	 while(($data=fgetcsv($handle, 1000, ","))!=FALSE){
	  $r++;
	//  echo 'nnnnnnn13';
	 if($r==1)
	 continue;
	 echo 'ýyyyyyy';
	$pass=md5($data[5]);
	 	$chechcourses=mysqli_num_rows(mysqli_query($con,"select * from users where user_ID='$data[0]'"));
	//echo 'nnnnnnn'.$data[$n];
	
	if($chechcourses<1){
	
	$insert=mysqli_query($con,"insert into users(user_ID,fullName,address,city,gender,email,password,phoneNo,userName)values('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$pass','$data[7]','$data[0]')") or die(mysqli_error($con));
	
	 }

	 echo 'hhhhhhhh';
	 }
	 
	// print_r( $hearders);
		/// close the final while loop
	 
		//fclose($handle);
	
	
	}
	?>
	 
	
	 
		<form enctype='multipart/form-data' action='' method='post'>
							
										
														
														
											 
													</div>
													
													<div class="col-md-6">
													
													
													
														
														 
	 
	 <div class="form-group">
															<label for="exampleInputEmail1">
																Select File
															</label>
	 
		<input size='50' type='file' name='filename'><br />
		</div>
	 
	  <input type='submit' name='upload' value='Upload'>
	  </form>
	 
 </div>   
													</div>
													</div>
													
													
													
														
						</div>
						
						
					</div>
				</div>
			
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>

<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
	$('#table_id').DataTable();
			} );
		</script>
</body>
</html>
