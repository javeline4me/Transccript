<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
$transactiondatetime = date("Y-m-d h:i:sa");
$qid = $_GET['id'];
//updating Admin Remark
if(isset($_POST['confim']))
		  {
$confirmstatus = $_POST['confirmstatus'];
$adminremark = $_POST['adminremark'];
if($confirmstatus=="1"){
	//echo "update transaction_details set  confirm_payment='$confirmstatus',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime' where tran_ID='$qid'";
$query=mysqli_query($con,"update transaction_details set  confirm_payment='$confirmstatus',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime', confirmationRemark = 'Success', trans_status = 'Confirmed'  where tran_ID='$qid'");
}else{
	$query=mysqli_query($con,"update transaction_details set  confirm_payment='$confirmstatus',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime', confirmationRemark = '$adminremark', trans_status = 'Confirmed'   where tran_ID='$qid'");
	
}
if($query){
echo "<script>alert('Admin confirmation was successfully.');</script>";
echo "<script>window.location.href ='unread-queries.php'</script>";
}
		  }
?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Transaction Details</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Transaction Details</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						

									<div class="row">
								<div class="col-md-12">
									<h5 class="over-title margin-bottom-15">View <span class="text-bold">Transaction Details</span></h5>
									<table class="table table-hover" id="sample-table-1">
		
										<tbody>
<?php
$qid = $_GET['id'];
$sql=mysqli_query($con,"select * from transaction_details t JOIN users u ON(u.user_ID=t.userID) where t.tran_ID='$qid'");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>

											<tr>
												<th>Full Name</th>
												<td><?php echo $row['fullName'];?></td>
											</tr>

											<tr>
												<th>Email Id</th>
												<td><?php echo $row['emailAddrerss'];?></td>
											</tr>
											<tr>
												<th>Conatact Numner</th>
												<td><?php echo $row['phnoneNumber'];?></td>
											</tr>
											<tr>
												<th>Transaction Ref./Teller No.</th>
												<td><?php echo $row['trans_ref_no'];?></td>
												</tr>
											<tr>
												<th>Amount</th>
												<td><?php echo "<span>&#8358;</span> ".number_format($row['transactionAmount'],2);?></td>
												</tr>

												<?Php } ?>
								
												
												</td>
												</tr>
								
											
											</form>												
															
											
										</tbody>
									</table>
								</div>
							</div>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
