<?php
include('PHPMailer/PHPMailerAutoload.php');
$applicantName = "Musa Johnmark";
$from = "doosem2012@gmail.com";
$institionalemail = "doogroup2018@gmail.com";
          $password = "Aondoyema2018?";
		$message = '<html>

            <body>';
                $message .= '<strong style="color:green;">This is to inform you that transcript for '.$applicantName.' is ready </strong>';
                $message .= '<p style="color:#080;font-size:18px;">Please Kindly click this link to print to received the Transcript </p>';
                $message .= '</body></html>';
				
            $mail = new PHPMailer();
            $mail->SMTPOption = array(
            'ssl'=> array(
            'verify_peer' =>false,
            'verify_peer_name' => false,
            'allow_self_signed'=>true
            )
            );
            $mail->SMTPKeepAlive = true;
            $mail->Mailer = "smtp";
            $mail->isSMTP();
            $mail->Host =gethostbyname('tls://smtp.gmail.com');
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAuth = true;
            $mail->Username = $from;
            $mail->Password = $password;
            $mail->FromName = "Joseph Tarka University Makurdi";
            $mail->Subject = 'The Transcript requested by :'.$applicantName;
            $mail->addAddress($institionalemail);
            $mail->msgHTML($message);
            //$mail->AddAttachment($file_name); // incase you are attaching a file uncomment.
            if($mail->send()) {
				//mysqli_query($con,"UPDATE request_transcript SET SendStatus = '1' ,SendDate = 'Am here' , SendByEmail = 'Online'  WHERE StudentNumber ='$matno' AND sendKey = '$mykey' AND SendStatus = '0' ");
                echo "Transcript delivered Successfully";
            }else{
				echo "Email Sent fails";
			}

?>