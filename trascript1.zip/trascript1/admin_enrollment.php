		<?php
		session_start();
		//error_reporting(0);
		include('include/config.php');
		include('include/checklogin.php');
		check_login();
		$userid2 = $_SESSION['id'];
			
$sql4 = mysqli_query($con,"select * from admin where id='".$_SESSION['id']."'");	
			$checnum = mysqli_num_rows($sql4);
			if($checnum>0){
			$sql1 = mysqli_query($con,"select * from admin where id='".$_SESSION['id']."'");	
			$datarow = mysqli_fetch_array($sql1);
			$reademail = $datarow['username'];

			$sql2 = mysqli_query($con,"select * from users where email = '$reademail' ");
			$datarows = mysqli_fetch_array($sql2);
			$phonenumber = $datarows['phoneNo'];
			$emailaddress = $datarows['email'];
			$username = $datarows['user_ID'];
			$userID = $datarows['id'];
			}else{
				$sql = mysqli_query($con,"select * from users where id='".$_SESSION['id']."'");
			$data = mysqli_fetch_array($sql);	

			$phonenumber = $data['phoneNo'];
			$emailaddress = $data['email'];
			$username = $data['user_ID'];
			$userID = $data['id'];
			}

		if(isset($_POST['submit']))
		{
			$transactiondatetime = date("Y-m-d h:i:sa");
			
			$converteddate = date("Y-m-d h:i:s");
			$trandatedate = date("Y-m-d");
			$timetransact = date("h:i:s");
			$milliseconds =  strtotime($converteddate);
			$autotransID = mt_rand();
			$transactioncode = $autotransID."-".$milliseconds;
			
			$pahases = $_POST['pahases'];
			$getphases = explode("/",$pahases);
			$phaseid = $getphases[0];
			$phaseamount = $getphases[1];
			$amount = $_POST['amount'];
			$bankcode = $_POST['bankcode'];
			$transdate = $_POST['transdate'];
			//$Rferrercode = $_POST['Rferrercode'];
			$Rferrercode = $_POST['Rferrercode'];
			$accounno = $_POST['accountno'];
			$bankName =$_POST['bankname'];
			
			$contactreferrer = mysqli_query($con, "SELECT * FROM transaction_details WHERE tran_ID = '$Rferrercode' AND memberPaidStatus = 'Pending' ");
			$getreferrerID = mysqli_num_rows($contactreferrer);
			$memberphase = mysqli_fetch_assoc($contactreferrer);
			$getphasevalue = $memberphase['entry_Type'];
			$chektellercode = $memberphase['trans_ref_no'];
			if($chektellercode!=$bankcode){
			//checking referrer phase
			//if($phaseid==$getphasevalue){
				
			$checkemrolment = mysqli_query($con, "SELECT * FROM transaction_details WHERE userID = '$userID' AND memberPaidStatus = 'Pending' ");
			$getcheck = mysqli_num_rows($checkemrolment);
			
			if($getcheck<1){
			$countcheckreferrer = mysqli_query($con, "SELECT * FROM transaction_details WHERE tran_ID = '$Rferrercode' ");
			$getcheckcount = mysqli_num_rows($countcheckreferrer);
				if($getcheckcount>0){
			//echo "INSERT INTO transaction_details(tran_ID,userID,entry_Type,transactionAmount,paymentMethod,transactionType,trans_ref_no,trans_status,paymentGateway,phnoneNumber,emailAddrerss,trans_Date_Time,transTime,trans_date,confirm_payment,confirmBy,dateConfirmed,Rferrercode,chainStatus) 
		//VALUES('$transactioncode','$userid','$phaseid','$amount','Bank','Deposite','$bankcode','pending','Deposite','$phonenumber','$emailaddress','$transactiondatetime','$timetransact','$trandatedate','0','','','$Rferrercode','Open')";
		$sql=mysqli_query($con,"INSERT INTO transaction_details(tran_ID,userID,entry_Type,transactionAmount,paymentMethod,transactionType,trans_ref_no,trans_status,paymentGateway,phnoneNumber,emailAddrerss,trans_Date_Time,transTime,trans_date,confirm_payment,confirmBy,dateConfirmed,Rferrercode,chainStatus,companyAccount,companyBank) VALUES('$transactioncode','$userid','$phaseid','$amount','Bank','Deposite','$bankcode','pending','Deposite','$phonenumber','$emailaddress','$transactiondatetime','$timetransact','$trandatedate','0','','','$Rferrercode','Open','$accounno','$bankName')");// or die(mysqli_error($con));

		$countreferrer = mysqli_query($con, "SELECT * FROM transaction_details WHERE Rferrercode = '$Rferrercode' ");
			$countvalue = mysqli_num_rows($countreferrer);
			//$countvalue = $getcount['totalrefer'];
		$getphase = mysqli_query($con, "SELECT * FROM promotion_level_type WHERE id = '$phaseid' ");
			
			$readphase = mysqli_fetch_assoc($getphase);
			$recapNo = $readphase['totalNumber'];
			$repayment = $readphase['amountqualified'];
			$bonusamt = $readphase['bonusamount'];
			mysqli_query($con,"insert into bonus_referrers(userID,referrerID,bonusType,bonusAmount,'',paidStatus) values('$userID','$Rferrercode','CR','$bonusamt','','1')");
			if($countvalue==$recapNo){
				$chainStatus = "Closed";
			mysqli_query($con,"UPDATE transaction_details SET chainStatus = '$chainStatus' WHERE tran_ID = '$Rferrercode' ");
			}
		if($sql)
		{
			
			$myrefrerid = mysqli_query($con, "SELECT * FROM transaction_details WHERE  memberPaidStatus = 'Pending' AND userID = '$userID' AND confirm_payment = '0'");
			$readrefer = mysqli_fetch_assoc($myrefrerid);
		$msg="Congratulations! your enrollment was Successfully. Your Referrer Id : ".$readrefer['tran_ID'];


		}
				}else{
					//generate overflowt
			mysqli_query($con,"insert into referrers_overflowt_details(user_ID,referrerID,usedStatus) values('$userID','$Rferrercode','1')");
			//check for the the higest order of entryAmount
			$pickfirstinlist = mysqli_query($con, "SELECT * FROM transaction_details WHERE chainStatus = 'Open'  ORDER BY   transTime ASC,trans_date ASC LIMIT 1 " );
			$readfirstlist = mysqli_fetch_assoc($pickfirstinlist);
			$firstlistreferrer = $readfirstlist['tran_ID'];
			//execute the transaction table
			$sql=mysqli_query($con,"INSERT INTO transaction_details(tran_ID,userID,entry_Type,transactionAmount,paymentMethod,transactionType,trans_ref_no,trans_status,paymentGateway,phnoneNumber,emailAddrerss,trans_Date_Time,transTime,trans_date,confirm_payment,confirmBy,dateConfirmed,Rferrercode,chainStatus,companyAccount,companyBank) VALUES('$transactioncode','$userID','$phaseid','$amount','Bank','Deposite','$bankcode','pending','Deposite','$phonenumber','$emailaddress','$transactiondatetime','$timetransact','$trandatedate','0','','','$firstlistreferrer','Open','$accounno','$bankName')");// or die(mysqli_error($con));
				//create debit
		mysqli_query($con,"insert into bonus_referrers(userID,referrerID,bonusType,bonusAmount,'',paidStatus) values('$userID','$Rferrercode','DR','$bonusamt','','1')");
				//echo "<script>alert('')</script>";	
			$myrefrerid = mysqli_query($con, "SELECT * FROM transaction_details WHERE  memberPaidStatus = 'Pending' AND userID = '$userID' AND confirm_payment = '0'");
			$readrefer = mysqli_fetch_assoc($myrefrerid);
		$msg="Congratulations! your enrollment was Successfully. Your Referrer Id : ".$readrefer['tran_ID'];	
				
				}
		}else{
			$msg="Sorry, You cannot Enter until you are Paid and Cleared Please.";
			
		}
			/*
			}else{
				
				$msg="Sorry, You cannot register outside your referrer. Kindly check the Group";
				
			}
			*/
			
			}else{
				
			$msg="Sorry, Avoid using duplicate transaction number please";	
			}

		}


		?>

<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
						
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">User | Make Payment</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>User </span>
									</li>
									<li class="active">
										<span>Make Payment</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<!--<div class="col-md-12">-->
<h5 style="color: green; font-size:18px; ">
<?php if($msg) { echo htmlentities($msg);}?> </h5>
									<!--<div class="row margin-top-30">-->
										<div class="col-lg-6 col-md-6">
											<div class="panel panel-white">
												<div class="panel-heading">
													<!--<h5 class="panel-title">Enter Bank Details</h5>-->
												</div>
												<div class="panel-body">
									<?php 
									
									if($emailaddress!=""){
									
									
$sql=mysqli_query($con,"select * from users where id='".$_SESSION['id']."'");
$data=mysqli_fetch_array($sql);
//while($data=mysqli_fetch_array($sql))
//{
?>
<h4><?php echo "Payment Details ".$data['user_ID']?></h4>

<hr />													<form role="form" name="edit" method="post">
													
													<div class="form-group">
															<label for="DoctorSpecialization">
																Select Phase category
															</label>
							<select name="pahases" class="form-control" required="true">
																<option value="">Select Phase</option>
														<?php $ret=mysqli_query($con,"select * from promotion_level_type where levelStatus = '1' ");
														while($row=mysqli_fetch_array($ret))
														{
														?>
													<option value="<?php echo htmlentities($row['id']."/".$row['entryAmount']);?>">
														<?php echo htmlentities($row['specilization'])." @ "?><span>&#8358;</span><?php echo number_format(($row['entryAmount']));?>
													</option>
													<?php } ?>
													
												</select>
											</div>
													<div class="form-group">
															<label for="fname">
																Amount Paid
															</label>
	<input type="text" name="amount" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
														</div>


												<div class="form-group">
															<label for="address">
																Bank Tell/Transfer Code
															</label>
					<input type="text" name="bankcode" class="form-control"   required>
														</div>
														<div class="form-group">
															<label for="address">
																Account No
															</label>
					<input type="text" name="accountno" class="form-control"   required>
														</div>
														<div class="form-group">
															<label for="address">
																Bank Name
															</label>
					<input type="text" name="bankname" class="form-control"   required>
														</div>
										<div class="form-group">
															<label for="city">
																 Transaction date
															</label>
		<input type="date" name="transdate" class="form-control"   required>
														</div>
														<!--
												<div class="form-group">
															<label for="address">
																Referrer Code
															</label>
					<input type="text" name="Rferrercode" class="form-control" value = "95763144-1622272520"  readonly>
														</div>
										-->
													<br/>
													<br/>

														
														
														
														
														<button type="submit" name="submit" class="btn btn-o btn-primary">
															Save
														</button>
													</form>
													<?php 
													
													}else{
													echo "<h4 style='color:red;' class='text-center'>Sorry you are using general Admin User. Go to Admin Menu to add Yourself as an Adminh</h4>";	
														
													}
														
													?>
												</div>
											</div>
										</div>
											
											<!--</div>
										</div>-->
									<div class="col-lg-6 col-md-6">
											<div class="panel panel-white">
												
									<img src="<?php echo $data['passporturl']; ?>"><br/>
									<br/>
									
										
											<h4><?php echo htmlentities($data['fullName']);?></h4>	
											</div>
										</div>
									</div>
								</div>
						
						<!-- end: BASIC EXAMPLE -->
			
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
