<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
//check_login();

if(isset($_GET["c"])){
$course=$_GET["c"];
$session=$_GET["s"];
$semester=$_GET["sem"];
$level=$_GET["l"];
$procat=$_GET["cat"];
$protype=$_GET["t"];

?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
    <script>
// Popup window code
function newWindow(url) {
	popupWindow = window.open(
		url,
		'popUpWindow','height=600,width=700,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
	<body>
		<div id="app">		
<?php include('include/examsidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Confirm Result</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Confirm Result</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						
								

								
													</div>
													
													
										
									<div class="row">
								<div class="col-md-12 table-responsive">
									<h5 class="over-title margin-bottom-15">Summary Result For: <span class="text-bold">Qualified Members</span></h5>
									<table class="table table-hover" id="table_id">
										<thead>
											<tr>
												<th class="center">Sno</th>
												<th>Mat No</th>
												<th class="hidden-xs">Name </th>
												<th>TCC </th>
												<th>TCE </th>
												<th>TPE</th>
                                                <th>GPA</th>
												<th>PTCC </th>
												<th>PTCE</th>
                                                <th>PTPE</th>
                                                <th>PGPA</th>
                                                <th>CCC</th>
                                                <th>CCE</th>
                                                <th>CPE</th>
                                                <th>CGPA</th>
												
											</tr>
										</thead>
										<tbody>
<?php

$sql = mysqli_query($con,"select * from transcript_tmpsenate where programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat'");
$cnt=1;
while($row=mysqli_fetch_assoc($sql))
{
	
?>

											<tr>
												<td class="center"><?php echo $cnt;?></td>
												<td class="hidden-xs"><a href="confirmresultexam?m=<?php echo $row['studentnumber']?>&&c=<?php echo $course ?>&&s=<?php echo $session ?>&&sem=<?php echo $semester ?>&&l=<?php echo $level?>&&t=<?php echo $protype?>&&cat=<?php echo $procat ?>"  target="popUpWindow"  onClick="newWindow(this.href)"><?php echo $row['studentnumber'];?></a></td>
												<td><?php echo $row['fullname'];?></td>
												<td><?php echo $row['tcc'];?></td>
												<td><?php echo $row['tce'];?></td>
												<td><?php echo $row['tpe'];?></td>
                                               <td><?php $gpa=$row['tpe']/$row['tcc'];  echo number_format($gpa,2);?></td>
                                                
												<td><?php echo $row['ptcc'];?></td>
                                                <td><?php echo $row['ptce'];?></td>
                                                <td><?php echo $row['ptpe'];?></td>
                                          <td><?php $pgpa=(intval($row['ptpe']/$row['ptcc']));  echo number_format($pgpa,2);?></td>
                                                <td><?php echo $row['ccc'];?></td>
                                                <td><?php echo $row['cce'];?></td>
                                                <td><?php echo $row['cpe'];?></td>
                                            <td><?php $cgpa=$row['cpe']/$row['ccc'];  echo number_format($cgpa,2);?></td>
												
											
                                            </tr>
											
											<?php 
									$cnt=$cnt+1;
											 //}
												}
											 ?>
											
											
										</tbody>
									</table>
								</div>
							</div>
                            <?php } ?>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		
  

		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
    $('#table_id').DataTable();
			} );
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
