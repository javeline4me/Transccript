<?php 

session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
if(isset($_GET["m"])){
$studnetno=$_GET["m"];
$course=$_GET["c"];
$session=$_GET["s"];
$semester=$_GET["sem"];
$level=$_GET["l"];
$procat=$_GET["cat"];
$protype=$_GET["t"];

$studname=mysqli_fetch_array(mysqli_query($con,"select * from users where user_ID='$studnetno'"));

$sql0 = mysqli_num_rows(mysqli_query($con,"select * from transcript_tmpsenate where studentnumber='$studnetno' and programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat' and cnf='1'"));
if($sql0<1){


$sql = mysqli_query($con,"select * from transcript_tblacademics where StudentNumber='$studnetno' and programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat'");
$cnt=1;

if(isset($_POST["confirm"])){

if($_POST["conf"]=='1'){

$sql2 = mysqli_query($con,"update transcript_tmpsenate set cnf='1' where studentnumber='$studnetno' and programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat'");

if($sql2){
echo '<script>alert("RESULT SUCCESSFULLY CONFIRMED")</script>';
}

}

}

?>

<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>

<body>
		<div id="app">		
			<div class="app-content">
				
					
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						
						<!-- end: PAGE TITLE -->
						
													
										

									<div class="row">
								<div class="col-md-12 table-responsive">
									<h5 class="over-title margin-bottom-15">Detail Result For: <span class="text-bold"><?php echo $studname["fullName"]?></span></h5>
                                    <form role="form" name="dcotorspcl" method="post" >
									<table class="table table-hover" id="table_id">
										<thead>
											<tr>
												<th class="center">Sno</th>
												<th>Course Code</th>
												<th>Course Title </th>
												<th>Score </th>
												<th>Grade </th>
												<th>Point</th>
                                               
												
											</tr>
										</thead>
										<tbody>
<?php


$cnt=1;
$tcc=0;
$tce=0;
$tpe=0;
while($row=mysqli_fetch_assoc($sql))
{
	
?>

											<tr>
												<td class="center"><?php echo $cnt;?></td>
												<td><?php  $avcourse=mysqli_fetch_array(mysqli_query($con,"select * from acd_avalaiblecourses where ID='{$row['Courseid']}'")); echo $avcourse['coursecode'];?></td>
												<td><?php echo  $avcourse['coursetitle'];?></td>
												<td><?php echo $row['Scorevalue'];?></td>
												<td><?php echo $row['grade'];?></td>
                                               <td><?php echo $row['points']?></td>
                                               <?php 
											   
											   $tcc+=$row["c_unit"];
											   if($row['points']>0){
											   $tce+=$row["c_unit"];
											   }
											   
											   $tpe+=$row["c_unit"]*$row['points'];
											   
											   ?>
                                                
                             </tr>
											
											<?php 
									$cnt=$cnt+1;
											 //}
												}
											 ?>
                                             
                                        <tr>
												<td >TCC:</td>
												<td><?php echo  $tcc ?></td>
												<td>TCE:</td>
												<td><?php  echo $tce?></td>
												<td>TPE</td>
                                               <td><?php echo  $tpe."    "?>GPA: <?php echo number_format($tpe/$tcc, 2)?></td>
                                                
                             </tr>     
                                             
											
											
										</tbody>
									</table>
                                    <input type="radio" id="html" name="conf" value="1">
  <label for="html">I confirm that the above scores are correctly entered</label><br>
                                    
                                  <input type="submit" id="" name="confirm" value="CONFIRM">   
                                    
                                    </form>
								</div>
							</div>
                           
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
					
					</div>
				</div>
			</div>
           
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		
  

		
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
        
        	<?php }else{?>
          <label for="html">RESULT ALREADY CONFIRMED</label><br>
          
          <?php }?>
          
         <?php }?>
         
          
        
	</body>
</html>