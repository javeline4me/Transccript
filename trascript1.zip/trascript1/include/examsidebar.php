<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="examofficerdashboard?dt=197.168.0.18">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
								<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage Result </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									<li>
								<a href="uploadresultexam2">
								<span class="title"> Upload Scores Live </span>
								</a>
								</li>

								<li>
								<a href="search_transcriptexam">
								<span class="title">View Result</span>
								</a>
								</li>
									<!--<li>
										<a href="search_upload_cgpa">
											<span class="title"> Upload GPA Live </span>
										</a>
									</li>
									<li>
										<a href="registration">
											<span class="title"> Upload Scores Live </span>
										</a>
									</li>-->
									<li>
										<a href="generate_grde_history_exm">
											<span class="title"> Grade History </span>
										</a>
									</li>
								</ul>
								</li>	

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>