<?php
$GLOBALS["count"]=0;
function GetSQLConnection() {
		
		$GLOBALS["SQL_CONNECTION"] = @mysqli_connect(DB_HOST,DB_USER,DB_PASS) or die(mysqli_error());
		
		@mysqli_select_db(DB_NAME) or die(mysqli_error());
	}

	function Execute($sql){
		if (!isset($GLOBALS["SQL_CONNECTION"]) or !$GLOBALS["SQL_CONNECTION"]) GetSQLConnection();
		//if(GetDbOPeration($_SESSION["username"],$sql) == true) return mysqli_query($sql);
		return mysqli_query($sql);
	}
	

	function Rfetch($sql) {
		if (!isset($GLOBALS["SQL_CONNECTION"]) or !$GLOBALS["SQL_CONNECTION"]) GetSQLConnection();
		return mysqli_fetch_array($sql);
	}
	
	function NumRow($sql) {
		if (!isset($GLOBALS["SQL_CONNECTION"]) or !$GLOBALS["SQL_CONNECTION"]) GetSQLConnection();
		return mysqli_num_rows($sql);
	}
	
	function myClose() {
		return @mysqli_close();
	}
	

function EncryptData($strg){
	for($i=0; $i<10;$i++)
  	{
    $str=strrev(base64_encode($strg)); //apply base64 first and then reverse the string
  	}
  return $str;
}

function DecryptData($strg){
	for($i=0; $i<10; $i++){
		$str=base64_encode(strrev($strg));
	}
	 return $str;
}

function VerifySession($uid){
	$qs = Rfetch( Execute("SELECT `role` FROM `user` WHERE( `staffid` = '{$_SESSION["ID"]}' AND `username` = '$uid' AND `role`= '{$_SESSION["role"]}')" ) );
	(isset($qs["role"]) && $qs["role"] !="")?NULL:die("ACCESS  DENIED");
}




function DisplayName($name){
	$qs = Rfetch(Execute("SELECT * from p_users u join p_employeedetails e on(u.username=e.employeeid) where u.username='{$_SESSION["user"]}' and e.e_status='1'"));
	
	return $qs["e_surname"]." ".$qs["e_firstname"];
}

function DisplayBranch($code){
$branch=Rfetch(Execute("select * from p_compbranches where branchcode='{$_SESSION["branch"]}'")) or die(mysqli_error());

 return $branch["branchname"];
}
function getRole($code){
$rol=Rfetch(Execute("select * from p_role where rolecode='{$_SESSION["role"]}'"));
return $rol["r_description"];
}

function valid_email($email) { 
  // First, we check that there's one @ symbol, and that the lengths are right 
  if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) { 
    // Email invalid because wrong number of characters in one section, or wrong number of @ symbols. 
    return false; 
  } 
  // Split it into sections to make life easier 
  $email_array = explode("@", $email); 
  $local_array = explode(".", $email_array[0]); 
  for ($i = 0; $i < sizeof($local_array); $i++) { 
     if (!ereg("^(([A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~-][A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) { 
      return false; 
    } 
  }   
  if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) { // Check if domain is IP. If not, it should be valid domain name 
    $domain_array = explode(".", $email_array[1]); 
    if (sizeof($domain_array) < 2) { 
        return false; // Not enough parts to domain 
    } 
    for ($i = 0; $i < sizeof($domain_array); $i++) { 
      if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) { 
        return false; 
      } 
    } 
  } 
  return true; 
}


function GenRanNum(){
//You can also use $stamp = strtotime ("now"); But I think date("Ymdhis") is easier to understand.
$year = date('Y'); // returns the current year
$yearID = $year[0].$year[3];
$m = date('m');  // returns the current month
$h = date('h'); // returns the current hour of the day
$mi = date('i'); // returns the current minute in an hour
$s = date('s'); // returns the current second in an hour
$d = date('d');
//$myID = $yearID.$s.$mi.$h.($mi + 1).($s + 11);
$myID = $yearID.$m.$d.$mi.$s;

return $myID;
}



function CheckSession(){
if(isset($_SESSION["securityCODE"]) && $_SESSION["securityCODE"] != "" ){
return NULL;
}
else{
unset($_SESSION["ID"]);
unset($_SESSION["username"]);
unset($_SESSION["is_logged"]);
unset($_SESSION["role"]);
die("YOUR SESSION HAS EXPIRED");
}

}




function SetDbMonitor($cod3,$cod2,$code,$userid,$operation,$table,$action){
if(Rfetch(Execute("SELECT `code` FROM `dbaudit` WHERE `code` = '$code' OR `code` = '$cod2' OR `code` = '$cod3'")) > 0){
Execute("UPDATE `dbaudit` SET `status` = $action WHERE `code` = '$code' AND `username` = '$userid' AND `operation` = '$operation' AND `tablename` = '$table'");
}
else{
Execute("INSERT INTO `dbaudit` VALUES('$code','$userid','$operation','$table','$action')");
}
}


function GetDbOPeration($userid, $query){
$q = $query;
if($userid == "")    return false;
  $newq = str_replace("`","_",$q);
  $newq = str_replace("("," ",$newq);
  $newq = str_replace(")"," ",$newq);
  $newq = str_replace("'","",$newq);
  $newq = str_replace("{","",$newq);
  $newq = str_replace("}","",$newq);
  $fx2 = explode(" ",$newq);
  if(trim(strtolower($fx2[0])) == "insert" || trim(strtolower($fx2[0])) == "update" ){
    if($_SESSION["DBKEY"] == ""){
	  $_SESSION["DBKEY"] = GenRanNum();
	  $path = $_SERVER['SCRIPT_FILENAME']; 
	  $modu = GetModule($paht);
	  $act = $fx2[0];
	  if(strtolower($act) == "insert"){
	   $tablename = $fx2[2];
	   $actionp = "INSERTING VALUES";
	   }
	  if(strtolower($act) == "update"){
	    $tablename = $fx2[1];
		$actionp = "UPDATING VALUES";
		}
		$tablename = str_replace("_","",$tablename); 
	   AddToMonitor($_SESSION["username"],$actionp,$_SESSION["DBKEY"],date('y/m/d h:i'),$modu,$tablename);
	   return true;
	}
	 else{
	  $path = $_SERVER['SCRIPT_FILENAME']; 
	  $modu = GetModule($path);
	  $act = $fx2[0];
	  if(strtolower($act) == "insert"){
	   $tablename = $fx2[2];
	   $actionp = "INSERTING VALUES";
	   }
	  if(strtolower($act) == "update"){
	    $tablename = $fx2[1];
		$actionp = "UPDATING VALUES";
		}
	   $tablename = str_replace("_","",$tablename);
	   AddToMonitor($_SESSION["username"],$actionp,$_SESSION["DBKEY"],date('y/m/d h:i'),$modu,$tablename);
	   return true;
	 }
	 
  }
  else{
    return true;
  }
   
}

function AddToMonitor($us,$action,$opid,$date,$mod,$table){
$act = ($action == "INSERTING VALUES") ? "insert" : "update" ;
$code1 = $us."insert_update".$table;
$code2 = $us.$act.$table;
$code3 = "allstaff"."insert_update".$table;
if(VerifyDbMonitor($code1,$code2,$code3,"0") == false){
$code = $_SESSION["username"].$_SESSION["ID"].$action.$table.GenRanNum();
mysqli_query("INSERT INTO `dbmonitor`
(`code`,`userid`,`actionperform`,`operationid`,`date`,`module`,`tablereference`) VALUES('$code','$us','$action','$opid','$date','$mod','$table')");
}
}

function GetModule($url){
$nurl = str_replace(":","_",$url);
$spliturl = explode("/",$nurl);
foreach($spliturl as $val){
if($val == "") continue;
//if($val == "Admin")       return ("ADMIN MODULE");
if($val == "accountant")      return ("AUDITOR MODULE");
if($val == "Staff")      return ("STAFF MODULE");
//if($val == "Manager")  return ("MANAGER MODULE");

}
return ("USER INTERFACE ");
}

function GenCode($length){
	 // start with a blank password
  $id = "";
  // define possible characters
  $possible = "123456789bcdfghjkmnpqrstvwxyzaeilouBCDFGHJKMNPQRSTVWXYZAEILOU";    
  // set up a counter
  $i = 0;    
  // add random characters to $password until $length is reached
  while ($i < $length) { 
    // pick a random character from the possible ones
    $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);   
    // we don't want this character if it's already in the password
    if (!strstr($id, $char)) { 
      $id .= $char;
	  echo $char."  ";
      $i++;
    }
  }
 // done!
  return $id;
}


function ClassDoDegree($matno){

$select=Execute("select * from enrollment where Student_StudentNumber='$matno'")or die(mysqli_error());;
$cur=0;
$cue=0;
$twgpa=0;
while($enrol=Rfetch($select)){

$course=Rfetch(Execute("select * from course where Code='{$enrol["Course_Code"]}'")) or die(mysqli_error());
 $gradin=Rfetch(Execute("select * from grading where `lower_score` <='{$enrol["Score"]}' and `upper_score`>='{$enrol["Score"]}'")) ;
 $tgp=$gradin["grade_point"]*$course["CreditUnits"];
$cur+=$course["CreditUnits"];
if($enrol["Score"]<40){
$cue+=0;

}else{
$cue+=$course["CreditUnits"];

}

$twgpa+=$tgp;

}

$cgpa=number_format($twgpa/$cur,2);
$clasofd=Rfetch(Execute("select * from classofdegree where lower_limit <='$cgpa' and upper_limit>='$cgpa'"))or die(mysqli_error());;

return   $clasofd["clasOfDegree"];
}

function generatePIN($digits){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}
/*
function GenRanNum(){
//You can also use $stamp = strtotime ("now"); But I think date("Ymdhis") is easier to understand.
$year = date('Y'); // returns the current year
$yearID = $year[0].$year[3];
$m = date('m');  // returns the current month
$h = date('h'); // returns the current hour of the day
$mi = date('i'); // returns the current minute in an hour
$s = date('s'); // returns the current second in an hour
$d = date('d');
//$myID = $yearID.$s.$mi.$h.($mi + 1).($s + 11);
$myID = $yearID.$m.$d.$mi.$s;

return $myID;
}*/
?>