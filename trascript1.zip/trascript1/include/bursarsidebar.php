<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="bursardashboard?dt=197.168.0.18">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
			

<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-files"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage Reports  </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="between-dates-reportsbr">
											<span class="title"> Between Dates Report </span>
										</a>
									</li>
                                    
									<li>
										<a href="unread-queriesbr">
											<span class="title"> Unread Queries</span>
										</a>
									</li>
                                    <li>
										<a href="bur_manage_members">
											<span class="title">Manage Members </span>
										</a>
									</li>
 <li>
										<a href="bur_viewAluminibyDeptadandsessiongraduated">
											<span class="title">Graduands </span>
										</a>
									</li>
								</ul>
								</li>

			
				
						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>