<footer>
				<div class="footer-inner">
					<div class="text-center">&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> JOSTUM</span>. <span>Developed by DICT</span>
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
				</div>
			</footer>