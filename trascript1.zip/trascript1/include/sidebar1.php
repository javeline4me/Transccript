<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="alumni_dashboard">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="myprofile">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-pencil-alt"></i>
										</div>
										<div class="item-inner">
											<span class="title"> My Profile </span>
										</div>
									</div>
								</a>
							</li>
								
							<li>
								<a href="enrollment">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-plus"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Click here to Pay </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="apply">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-plus"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Apply for Transcript </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="myenrollment-history">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> My History </span>
										</div>
									</div>
								</a>
							</li>
							
								<li>
								<a href="mypaymenthistory">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Payment Details </span>
										</div>
									</div>
								</a>
							</li>
								
						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>