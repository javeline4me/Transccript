<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard?dt=197.168.0.18">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Setting </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
								<li>
										<a href="admintype.php">
											<span class="title"> Setup Admin Type </span>
										</a>
									</li>
									<li>
										<a href="phase_setup.php">
											<span class="title"> Setup Amount </span>
										</a>
									</li>
									<li>
										<a href="add_adminusers.php">
											<span class="title"> Add New Admin</span>
										</a>
									</li>
									<li>
										<a href="manage_admin_users.php">
											<span class="title"> Manage Admin </span>
										</a>
									</li>
									<li>
										<a href="reatebank_details.php">
											<span class="title"> Manage Account Details </span>
										</a>
									</li>
								</ul>
								</li>

				<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage School </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								
								<ul class="sub-menu">
									
									<li>
										<a href="departments">
											<span class="title"> Manage Departments </span>
										</a>
									</li>
									<li>
										<a href="faculties">
											<span class="title"> Manage Colleges </span>
										</a>
									</li>
									<li>
										<a href="programofStudy">
											<span class="title"> Manage Programs </span>
										</a>
									</li>
									<li>
										<a href="courses_units">
											<span class="title"> Manage Course Units </span>
										</a>
									</li>
									
								</ul>
								</li>
								<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Members </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="manage-members">
											<span class="title"> Manage Members </span>
										</a>
									</li>
									<li>
										<a href="registration">
											<span class="title"> Add New Members </span>
										</a>
									</li>
									<li>
										<a href="uploadAlumini">
											<span class="title"> Upload Members </span>
										</a>
									</li>
									
								</ul>
								</li>	

							<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage Result </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									<li>
									<a href="uploadresult2">
									<span class="title"> Upload Scores Live </span>
									</a>
									</li>

									<li>
									<a href="viewResult">
									<span class="title">View Result</span>
									</a>
									</li>
									<li>
										<a href="confirm_transcriptlist">
											<span class="title"> Confirm Transcript </span>
										</a>
									</li>
									<li>
										<a href="setupgraduating_point">
											<span class="title"> Setup Graduating Points </span>
										</a>
									</li>
									<li>
										<a href="generate_grde_history">
											<span class="title"> Grade History </span>
										</a>
									</li>
								</ul>
								</li>	


							<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-files"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage Transactions </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="unread-queries.php">
											<span class="title"> Confirm Payments </span>
										</a>
									</li>

									<li>
										<a href="read-query.php">
											<span class="title"> Query Transactions </span>
										</a>
									</li>
									
								</ul>
								</li>

<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-files"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Manage Transcript </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="panding_application">
											<span class="title"> Process Transcript </span>
										</a>
									</li>

									<li>
										<a href="read-query.php">
											<span class="title"> Query Transactions </span>
										</a>
									</li>
									
								</ul>
								</li>


	<li>
								<a href="doctor-logs.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Session Logs </span>
										</div>
									</div>
								</a>
							</li>		



							<!--<li>
								<a href="listdue_forpayment.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Winers List </span>
										</div>
									</div>
								</a>
							</li>	-->					
				<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-files"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Reports </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="between-dates-reports">
											<span class="title">B/w dates reports </span>
										</a>
									</li>

									<li>
										<a href="search_transcript">
											<span class="title">Search for Transcript </span>
										</a>
									</li>

									
								</ul>
								<li>
								<a href="member-search.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-search"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Member Search </span>
										</div>
									</div>
								</a>
							</li>
								</li>

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>