 <div class="kingster-mobile-header-wrap">
        <div class="kingster-mobile-header kingster-header-background kingster-style-slide kingster-sticky-mobile-navigation " id="kingster-mobile-header">
            <div class="kingster-mobile-header-container kingster-container clearfix">
                <div class="kingster-logo  kingster-item-pdlr">
                    <div class="kingster-logo-inner">
                        <a class="" href="index.php"><img src="images/logo.png" alt="" /></a>
                    </div>
                </div>
                <div class="kingster-mobile-menu-right">
                    
                    
                    <div class="kingster-mobile-menu"><a class="kingster-mm-menu-button kingster-mobile-menu-button kingster-mobile-button-hamburger" href="#kingster-mobile-menu"><span></span></a>
                        <div class="kingster-mm-menu-wrap kingster-navigation-font" id="kingster-mobile-menu" data-slide="right">
                           <ul id="menu-main-navigation-1" class="sf-menu">
                                    <li class="menu-item menu-item-home current-menu-item menu-item-has-children kingster-normal-menu">
                                        <a href="index.php" class="sf-with-ul-pre">Home</a>
                                        
                                    </li>
                                    <li class="menu-item menu-item-has-children" data-size="60">
                                        <a href="admission_requirement.php" class="sf-with-ul-pre">Admission Requirements</a>
                                            </li>
                                            <li class="menu-item" data-size="60"><a href="start-application.php">Apply for Admission</a></li>
                                           
                                               
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="check-status.php" class="sf-with-ul-pre">check Status</a>
                                                        
                                                    </li>
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="print-document.php" class="sf-with-ul-pre">Print Documents</a>
                                                        
                                                    </li>
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="login.php" class="sf-with-ul-pre">Login</a>
                                                        
                                                    </li>

                                             
                                   </ul>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>