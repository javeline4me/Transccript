<?php
session_start();
error_reporting(0);
include('includes/EntityManager.php') ;
//include('includes/ProcessorVendor.php');
$userid = $_GET['userid'];

$con = EntityManager::getEntityManager() ;
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index"); 
    }
    else{
		//check and Protect the page
$user_id = $_SESSION['alogin'];

$getdeptcode =  $con->query("SELECT * FROM department_regofficer_setup WHERE computer_id = '$user_id'")->fetch(PDO::FETCH_ASSOC);
		    $deptcode = $getdeptcode['depatcode'];


$visiturls = substr( $_SERVER['REQUEST_URI'], strrpos( $_SERVER['REQUEST_URI'],"/")+1);
		$exploadpage = explode("?",$visiturls);
		$visiturl = $exploadpage[0];
		$urlpages = $visiturl.".php";
	
		$getpage = $con->prepare("SELECT * FROM setup_personal_right WHERE  pages = ? AND username = ? "); 
		
		$getpage->execute( array( $urlpages, $user_id ) );
		
		$myurlpages = $getpage->fetchObject();
		
		$usepage = $myurlpages->pages;
		$myurl = explode(".",$usepage);
		  $redirecturl = $myurl[0];
		if($redirecturl===$visiturl){
		//End checked

//$readstaff = $con->query(" SELECT * FROM hr_staff_details WHERE computerid = '$userid' ")->fetchObject();
					//$fullnames = $readstaff->Salutations." ".$readstaff->Surname." ".$readstaff->MiddleName." ".$readstaff->LastName;
		//$staffid = $readstaff->Staffid;


if(isset($_POST['remove'])){
	
	for($i=0; $i<count($_POST["removedutycode"]); $i++){
		$rolesid = $_POST['removedutycode'][$i];
		
		$delete = $con->query(" DELETE FROM user_roles WHERE user_Id = '$userid' AND userroletype_id = '$rolesid' ");	
		
		$delete = $con->prepare(" DELETE FROM  setup_personal_right WHERE username = ? AND userroletype_id = ? ");
		$delete->execute( array( $userid, $rolesid ) );
	}
	if($delete){
		/*
		$user_id = $userid;
		$getRoles = $con->prepare("SELECT * FROM  user_roles WHERE user_id = ? AND role_Status = ? ");
		$getRoles->execute( array( $user_id, 1 ) );
		if($getRoles->rowCount()>0){
			
		while($readroles = $getRoles->fetchObject()){
			$RoleType = $readroles->role_Type;
			$userrolecode = $readroles->userroletype_id;
			
			$readtab = $con->prepare("SELECT * FROM duty_type_menus d JOIN setup_file_menus s ON(d.menucode=s.menucode)WHERE d.dutycode = ? AND d.rightstatus = ?");
			$readtab->execute(array( $RoleType, 1 ));
			
			while( $getmenus = $readtab->fetchObject()){
				$tabcode = $getmenus->tabcode;
				$menucode = $getmenus->menucode;
				$pages = $getmenus->name;
				echo $user_id." Tabs ".$tabcode." Menue ".$menucode." Pages ".$pages;
				$code = $user_id.$RoleType.$tabcode.$menucode;
				
				$insertrols = $con->prepare(" INSERT INTO setup_personal_right(	code, menucode, username, assignby, tabcode, status, pages, dutyrole, userroletype_id  ) VALUES( ?, ?, ?, ?, ?, ?, ?, ?, ? )");
				$insertrols->execute( array( $code, $menucode, $user_id, $user_id, $tabcode, 1, $pages, $RoleType, $userrolecode ));
			}
		}			
			
			
		}
		*/
		$msg = "Role Deleted Successfully";
	}
}

?>
<!DOCTYPE html>
<html lang="en">
    <?php include('includes/htmlheader.html'); ?>
    <body class="top-navbar-fixed">
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
  <?php include('includes/topbar.php');?> 
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->
                   <?php include('includes/leftbar.php');?>  
                    <!-- /.left-sidebar -->

                    <div class="main-page">

                     <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-12">
                                    <h2 class="title">REQUEST TRANSACTION BY RRR</h2>
                                
                                </div>
                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
                                        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                                
                                        <li class="active"></li>
                                    </ul>
                                </div>
                             
                            </div>
                            <!-- /.row -->
                        </div>
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                           
                                            <div class="panel-body">
							
							<div class="bs-exp">
												
											<div class="tab-content">
												
											<div class="fa fa-success"><?php echo $msg?></div>
										<div class = "row">
										
											<div class = "col-md-12">
											<h4 class="mt-2"></h4>
											
											 <form class="form-horizontal" method="post" name="managestatus">
                           <div class="row">
                           <div class="col-md-5">			
                        <div class="form-group has-success">
				<label for="inputEmail">Search by RRR No</label>
				<div class="controls">
                                    <input type="text" id="searchval" name="searchval"  required class="form-control">
				</div>
				
                        </div>
						</div>
						
              <div class="col-md-2">          
			<div class="control-group">
			<label for="inputEmail">&nbsp;&nbsp;</label>
				<div class="controls">
				<button name="submit_status" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Search</button>
				</div>
			</div>
			</div>
			</div>
					</form>
											<form name="addUserForm" method="POST">
											 <?php
					if(isset($_POST['submit_status'])){
						$transdates = $_POST['paydate'];
						
				$searchdetails = $con->query("select * from pay_main_transaction WHERE RRR='{$_POST['searchval']}' ")->rowCount();	
					if($searchdetails>0){
					?>
					
					<table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Reg. No</th>
                                                    <th>Full Name</th>
                                                    <th>RRR/Amount</th>
													<th>Payment Description</th>
													<th>Reset</th>
                                                </tr>
                                            </thead>
											<?php
										//echo "select * from app_application a JOIN pay_main_transaction p ON(p.StudentNumber=a.applicationno) WHERE a.applicationno='{$_POST['searchval']}' AND p.transactiondate = '$transdates' ";
											$data = $con->query("select * from  pay_main_transaction a  WHERE a.RRR='{$_POST['searchval']}' ");
											while($getdate = $data->fetch(PDO::FETCH_ASSOC)){
												$regNo = $getdate['StudentNumber'];
												$changematno = explode("/",$regNo);
												$first = !empty($changematno[0])?$changematno[0]:"";
												$second = !empty($changematno[1])?$changematno[1]:"";
												$third = !empty($changematno[2])?$changematno[2]:"";
												$full = $first."_".$second."_".$third;
												$paymentdescription = $getdate['paymentdescription'];
												$RRR = $getdate['RRR'];
												/*
												 $fullname = $getdate['Firstname']." ".$getdate['middlename']." ".$getdate['Lastname'];
												 $RRR = $getdate['RRR'];
												 $Amount = $getdate['Amount'];
												 $paymentdescription = $getdate['paymentdescription'];
												 $trainId = $getdate['trainId'];
												 */
												 $fullName = $getdate['RRR'];
												 
											?>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td><?php echo $regNo?></td>
                                                    <td><?php echo $fullname ?></td>
                                                    <td><?php echo $RRR?></td>
													<td><?php echo $paymentdescription?></td>
													<td>
													<a href="requery_by_rrr?rrrno=<?php echo $RRR;?>"><i class="fa fa-eraser" title="Reset Payment" aria-hidden="true"></i> </a>
													</td>
                                                </tr>
                                                
                                                
                                            </tbody>
											<?php
											}
												}
											?>
                                        </table>
												<?php
					
					}
					
					?>
												
												</form>
												</div>
												
                                         </div>
                                                <!-- /.col-md-12 -->
                                            </p>
										
        
									</div>
									</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
                    </div>
                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->
        </div>
        <!-- /.main-wrapper -->
        <?php include('includes/htnlFooter.html'); ?>
		</body>
</html>
<?PHP 
}
		else{
			//$terminatemgs = "Session terminated, Please login again";
header("location:logout.php"."?sessionerror=".$terminatemgs);
}
} ?>
<?php include("commons/web-commons.php") ; ?>
<?php include("commons/select-commons.php") ; ?>
<script>
$(document).ready(function(){ 
	 $("#myTab a:first").tab('show'); // show last tab on page load
});
</script>
