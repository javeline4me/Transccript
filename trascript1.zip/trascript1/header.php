  <header class="kingster-header-wrap kingster-header-style-plain  kingster-style-menu-right kingster-sticky-navigation kingster-style-fixed" data-navigation-offset="75px">
                <div class="kingster-header-background"></div>
                <div class="kingster-header-container  kingster-container">
                    <div class="kingster-header-container-inner clearfix">
                        <div class="kingster-logo  kingster-item-pdlr">
                            <div class="kingster-logo-inner">
                                <a class="" href="#"><img src="logo.png" alt="" /></a>
                            </div>
                        </div>
                        <div class="kingster-navigation kingster-item-pdlr clearfix ">
                            <div class="kingster-main-menu" id="kingster-main-menu">
                                <ul id="menu-main-navigation-1" class="sf-menu">
                                    <li class="menu-item menu-item-home current-menu-item menu-item-has-children kingster-normal-menu">
                                        <a href="#" class="sf-with-ul-pre">Home</a>
                                        
                                    </li>
									 <li class="menu-item" data-size="60"><a href="createaccount?dg=197.234.168.1" target="_blank">Apply for Transcript</a></li>
                                   <!-- <li class="menu-item menu-item-has-children" data-size="60">
                                        <a href="admission_requirement.php" class="sf-with-ul-pre">Admission Requirements</a>
                                            </li>
                                           
                                           
                                               
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="check-status.php" class="sf-with-ul-pre">check Status</a>
                                                        
                                                    </li>
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="print-document.php" class="sf-with-ul-pre">Print Documents</a>
                                                        
                                                    </li>-->
                                                    <li class="menu-item menu-item-has-children">
                                                        <a href="alumnilogin?ig=197.27.36.1" class="sf-with-ul-pre" target="_blank">Login</a>
                                                        
                                                    </li>

                                             
                                   </ul>
                                <div class="kingster-navigation-slide-bar" id="kingster-navigation-slide-bar"></div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </header>