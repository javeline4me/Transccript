<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();


if(isset($_POST['submit']))
		{
		//create records
				$fname=$_POST['full_name'];
				$programs=$_POST['programs'];
				$department=$_POST['department'];
				$gender=$_POST['gender'];
				$programtype=$_POST['programtype'];
				$programcategory = $_POST['programcategory'];
				$matno = $_POST['matno'];
				$password=md5($matno);
				$level = $_POST['level'];
				$sessionid = $_POST['sessionid'];
				$usernames = $matno;
			$checkinsert = mysqli_query($con,"SELECT * FROM users WHERE user_ID = '$matno' ");
			if(mysqli_num_rows($checkinsert)<1){
				//echo "insert into users(user_ID,fullName,deptID,gender,ProgramID,ProgramCategory,ProgramType,graduatedLevelID,SessionGraduatedID) values
			//('$matno','$fname','$department','$gender','$programs','$programcategory','$programtype','$level','$sessionid')";
				
			$query=mysqli_query($con,"insert into users(user_ID,fullName,deptID,gender,ProgramID,ProgramCategory,ProgramType,graduatedLevelID,SessionGraduatedID) values
			('$matno','$fname','$department','$gender','$programs','$programcategory','$programtype','$level','$sessionid')");	
				
			if($query)
			{
				echo '<script>alert("Record Added Successfully")</script>';
			}else{
				echo '<script>alert("Sorry, Record could not Added Successfully")</script>';
			}
		}else{
		echo '<script>alert("Sorry, This Record has been added")</script>';	
		}
		}
?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/academicsidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
					<img src="assets/images/logo.png" alt=""/>
				</div>
				<!-- start: REGISTER BOX -->
				<div class="box-register">
					<form name="registration" id="registration"  method="post">
						<fieldset>
							<legend>
								Alumni Infor
							</legend>
							<p>
								Enter Member's details below:
							</p>
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="matno" id="matno"   placeholder="Matriculation Number" required>
									<i class="fa fa-user"></i> </span>
									 
							</div>
							
							<div class="form-group">
								<input type="text" class="form-control" name="full_name" placeholder="Full Name" required>
							</div>
							<div class="form-group">
								<!--<input type="text" class="form-control" name="address" placeholder="Address" required>-->
								<select class="form-control" name="programs" placeholder="programs" required>
								<option value=""> Select Programs </option>
								<?php
								$getprogram = $con->query("SELECT * FROM courselist order by cosname ASC");
								while($row = mysqli_fetch_array($getprogram)){
								?>
								<option value="<?php echo $row['coscode']?>"><?php echo $row['cosname']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<div class="form-group">
								<select class="form-control" name="department" placeholder="department" required>
								<option value=""> Select Department </option>
								<?php
								$getprograms = $con->query("SELECT * FROM acd_department where faccode !=13 order by deptname ASC");
								while($rows = mysqli_fetch_array($getprograms)){
								?>
								<option value="<?php echo $rows['deptcode']?>"><?php echo $rows['deptname']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<div class="form-group">
								<select class="form-control" name="programtype" placeholder="programtype" required>
								<option value=""> Select Program Type </option>
								<?php
								$getprogramtype = $con->query("SELECT * FROM programmes  order by programme DESC");
								while($rowtype = mysqli_fetch_array($getprogramtype)){
								?>
								<option value="<?php echo $rowtype['program_id']?>"><?php echo $rowtype['programme']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<div class="form-group">
								<select class="form-control" name="programcategory" placeholder="programcategory" required>
								<option value=""> Select Study Type </option>
								<?php
								$getprogramcat = $con->query("SELECT * FROM program_category  order by prog_cat_name ASC");
								while($rowcat = mysqli_fetch_array($getprogramcat)){
								?>
								<option value="<?php echo $rowcat['prog_cat_id']?>"><?php echo $rowcat['prog_cat_name']?></option>
								<?php
								}
								?>
								</select>
							</div>
							
							<div class="form-group">
								<select class="form-control" name="level" placeholder="level" required>
								<option value=""> Select Study Level </option>
								<?php
								$getprogrmlevel = $con->query("SELECT * FROM acd_avalaiblelevel  order by levelcode ASC");
								while($rowlevel = mysqli_fetch_array($getprogrmlevel)){
								?>
								<option value="<?php echo $rowlevel['id']?>"><?php echo $rowlevel['levelcode']?></option>
								<?php
								}
								?>
								</select>
							</div>
							
							<div class="form-group">
								<select class="form-control" name="sessionid" placeholder="sessionid" required>
								<option value=""> Select Session </option>
								<?php
								$getsession = $con->query("SELECT * FROM acd_add_session  order by SessionName DESC");
								while($rowsession = mysqli_fetch_array($getsession)){
								?>
								<option value="<?php echo $rowsession['session_id']?>"><?php echo $rowsession['SessionName']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<div class="form-group">
								<label class="block">
									Gender
								</label>
								<div class="clip-radio radio-primary">
									<input type="radio" id="rg-female" name="gender" value="female" >
									<label for="rg-female">
										Female
									</label>
									<input type="radio" id="rg-male" name="gender" value="male">
									<label for="rg-male">
										Male
									</label>
								</div>
							</div>
							
							
							<div class="form-group">
								<div class="checkbox clip-check check-primary">
									<input type="checkbox" id="agree" value="agree" required>
									<label for="agree">
										The information above is correctly entered
									</label>
								</div>
							</div>
							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" id="submit" name="submit">
									Submit <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
						</fieldset>
					</form>

					

				</div>

			</div>
		</div>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		
  

		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
    $('#table_id').DataTable();
			} );
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
