<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
$matno = $_GET['viewid'];
 
?>

<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/academicsidebar.php');?>
<div class="app-content">
<?php include('include/header.php');?>
<div class="main-content" >
<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
<section id="page-title">
<div class="row">
<div class="col-sm-8">
<h1 class="mainTitle">Admin | Transcript Report</h1>
</div>
<ol class="breadcrumb">
<li>
<span>Admin</span>
</li>
<li class="active">
<span>Transcript Report</span>
</li>
</ol>
</div>
</section>
<div class="container-fluid container-fullw bg-white">
<div class="row">
<div class="col-md-12">
<h5 class="over-title margin-bottom-15"> <span class="text-bold">Transcript Report</span></h5>
<h5 align="center" ><a href="send_detailsPDF?viewid=<?php echo $matno ?>">PDF</a></h5>
<?php
                               $vid=$_GET['viewid'];
                               $ret=mysqli_query($con,"select * from users u join courselist t ON(u.ProgramID=t.coscode) join acd_avalaiblelevel v ON(v.id=u.graduatedLevelID) join acd_department d ON(d.deptcode=u.deptID) join faculties f ON(d.faccode=f.faccode) join acd_add_session s ON(s.session_id=u.SessionGraduatedID) where u.user_ID='$vid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
                               ?>
<table border="1" class="table table-bordered">
 <tr align="center">
<td colspan="4" style="font-size:20px;color:blue">
 
                               <h2>JOSEPH SARWUAN TARKA UNIVERSITY, MAKURDI </h2>
                                    <h4>(Office of the Registrar) </h4>
                                         <h2> <img src="logo1.png" alt="" /></h2>
                                         <h2> ACADEMIC TRANSCRIPT</h2>
                                         <h2> (For external use only)</h2>
                                         
                                         </td></tr>
 <tr align="center">
<td colspan="4" style="font-size:20px;color:blue">
 Candidate's Details</td></tr>

    <tr>
    <th scope>Full Name(Surname First)</th>
    <td><?php  echo $row['fullName'];?></td>
    <th scope>Student Number</th>
    <td><?php  echo $row['user_ID'];?></td>
  </tr>
  <tr>
    <th scope>Memebers Mobile Number</th>
    <td><?php  echo $row['phoneNo'];?></td>
    <th>Date Of Birth</th>
    <td><?php  echo $row['address'];?></td>
  </tr>
    <tr>
    <th>Memebers Gender</th>
    <td><?php  echo $row['gender'];?></td>
    <th>Registration Date</th>
    <td><?php  echo $row['regDate'];?></td>
  </tr>
</table>

<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" >Academic Details</th> 
  </tr>
  <tr>
  
<th>Course/Specialization</th>
<th>Department</th>
<th>College</th>
<th>Session Admitted</th>
<th>Session Graduated</th>
<th>Status</th>
</tr>

<tr>
  
 <td><?php  echo $row['cosname'];?></td>
 <td><?php echo $row['deptname'];?></td>
 <td><?php  echo $row['facname'];?></td> 
  <td><?php  echo $row['SessionAdmittedID'];?></td>
  <td><?php  echo $row['SessionName'];?></td>
  <td><?php   echo $row['graduateStus'];?></td> 
</tr>
<?php }?>

</table>
    Result Details
	 <?php
	 $getlevels = mysqli_query($con,"SELECT DISTINCT sessionid,levelid FROM transcript_tmpsenate WHERE StudentNumber = '$matno' ");
	 while($readlevel = mysqli_fetch_array($getlevels)){
		 $mysession = $readlevel['sessionid'];
		 $levelid = $readlevel['levelid'];
		 $sessiondetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_add_session WHERE session_id = $mysession"));
		 
		 $leveldetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_avalaiblelevel WHERE id = $levelid"));
		 
		$getsemesterid = mysqli_query($con,"SELECT DISTINCT semesterid FROM transcript_tmpsenate WHERE StudentNumber = '$matno' ORDER BY semesterid ASC");
	 while($readsemesterid = mysqli_fetch_array($getsemesterid)){
		 $semesterid = $readsemesterid['semesterid']; 
		 
		 $semesterdetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_semester WHERE semestercode = $semesterid"));
	 ?>
<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" ><?php echo "Level: ".$leveldetails['levelcode']."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Year: ".$sessiondetails['SessionName']." &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ".$semesterdetails['semestername'] ?></th> 
  </tr>
  <tr>
  
<th>Course Code</th>
<th>Course Title</th>
<th>Credit Unit</th>
<th>Letter Grade</th>
<th>Grade Points</th>
<th>Weightted <br>Grade Points</th>
</tr>

<tr>
  <?php

$cnt=1;
$tcc=0;
$tce=0;
$tpe=0;	
$datafor_result = mysqli_query($con,"select * from transcript_tblacademics t JOIN acd_avalaiblecourses c ON(c.ID=t.CourseID) WHERE t.StudentNumber = '$matno' AND  t.sessionid = '$mysession' AND t.semesterid = '$semesterid' AND t.levelid='$levelid'") ;

while($getdate = mysqli_fetch_array($datafor_result)){
	$cosecode = $getdate['coursecode'];
	 $cosetitle = $getdate['coursetitle'];
	 $crditunit = $getdate['c_unit'];
	 $Points = $getdate['points'];
	 $grade = $getdate['grade'];
	 $sno++;
	 $gradepoints = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM tb_score_gradehistory WHERE sessions = $mysession AND grade = '$grade' ")); 
	 $intvalpoint = $gradepoints['unitvalue'];
	 
	 $weightpoints = $crditunit * $intvalpoint;
?>
 
<td><?php echo $cosecode?></td>
<td><?php echo $cosetitle ?></td>
<td><?php echo $crditunit?></td>
<td><?php echo $grade?></td>
<td><?php echo $Points?></td>

<td><?php echo $weightpoints;?></td>
</tr>
<?php 
 $tcc+=$row["c_unit"];
											   if($row['points']>0){
											   $tce+=$row["c_unit"];
											   }
											   $tpe+=$row["c_unit"]*$row['points'];
											  $cnt=$cnt+1;	

}?>
</table> 

	  <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" ><?php echo "PERFORMNANCE " ?></th> 
  </tr>
  <?php
	// }
	 
	 
	$getpeformance = mysqli_query($con, "SELECT * FROM transcript_tmpsenate WHERE studentnumber='$matno' ");
	while($readgrade = mysqli_fetch_array($getpeformance)){ 
	$tcc = $readgrade['tcc'];
	 $tce = $readgrade['tce'];
	 $tpe = $readgrade['tpe'];
	 $ccc = $readgrade['ccc'];
	 $cce = $readgrade['cce'];
	 $cpe = $readgrade['cpe'];
	 $gpa = number_format($tpe/$tcc, 2);
	// $cgpa = ;
	 }
	 ?>
     <tr>
  
<th>TCC:<?php echo $tcc;?> </th>
<th>TCE: <?php echo $tce;?></th>
<th>TPE:<?php echo $tpe;?> </th>
<th>GPA:<?php echo number_format($tpe/$tcc, 2)?> </th>
<th>CCC: <?php echo $ccc;?> </th></th>
<th>CCE: <?php echo $cce;?> </th></th>
<th>CPE: <?php echo $cpe;?> </th></th>
<?php $gpa= number_format($tpe/$tcc, 2);
$cgpa =$cgpa + $gpa;

?>
<th>CGPA:<?php echo $cgpa ?> </th>
</tr>
</table>

<?php
	 }
	 
	 
	 //$getgradingsystem = mysqli_query($con, "SELECT * FROM tb_score_gradehistory WHERE sessions='$mysession' ");
	 //while($readgrade = mysqli_fetch_array($getgradingsystem)){
	 ?>
	 <div class="row">
	 <div class="col-sm-8">
	<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" ><?php echo "GRADING SYSTEM(FIRST DEGREES) " ?></th> 
  </tr>
  <tr>
  
<th> SCORE(%)</th>
<th>LETTER GRADE </th>
<th>GRADE POINT </th>

</tr>
	
<tr>
<?php
	$getgradingsystem = mysqli_query($con, "SELECT * FROM tb_score_gradehistory WHERE sessions='$mysession' ");
	 while($readgrade = mysqli_fetch_array($getgradingsystem)){
	 ?>
<td><?php echo $readgrade['value1']." - ".$readgrade['value2']?></td>
<td><?php echo $readgrade['grade']?></td>
<td><?php echo $readgrade['unitvalue']?></td>

</tr>
<?php
	 }
	 ?>
</table> 
</div>
<div class="col-sm-4">
	 <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" ><?php echo "GRADING SYSTEM(FIRST DEGREES) " ?></th> 
  </tr>
  <tr>
  

<th>CGPA </th>
<th>CLASS OF DEGREE </th>
</tr>
	
<tr>
<?php
	$getcgpa = mysqli_query($con, "SELECT * FROM acd_cgpagradingsystem ");
	 while($readcgpa = mysqli_fetch_array($getcgpa)){
	 ?>
<td><?php echo number_format($readcgpa['lowercgpa'],2)." - ".number_format($readcgpa['highercgpa'],2)?></td>
<td><?php echo $readcgpa['classofdegreedescription']?></td>

</tr>
<?php
	 }
	 ?>
</table> 
</div>
</div>
	 <?php
	 //}
	 }
	 ?>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
