<?php 
include('include/config.php');
include('include/checklogin.php');
include('include/transcript.func.php');
//check_login();
session_start();
ob_start();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
	include("include/headerscript.html");
	?>

<body>

<div id="app">		
<?php include('include/examsidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Confirm Result</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Confirm Result</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						<div class="rows">
													<div class="col-md-6">
								
	 
	<?php
	 
	//include "connection.php"; //Connect to Database

	//Upload File
	if (isset($_POST['upload'])) {
	$course=$_POST["course"];
	$session=$_POST["session"];
	$semester=$_POST["semester"];
	$level=$_POST["level"];
	$procat=$_POST["progcat"];
	$protype=$_POST["protype"];
		$handle = fopen($_FILES['filename']['tmp_name'], "r");
		$handle2=fopen($_FILES['filename']['tmp_name'], "r");
		//Import uploaded file to Database
	   $hearders=array();
	 $j=2;
	 $t=1;
	 while(($dat=fgetcsv($handle, 1000, ","))!=FALSE){
	 if($t>1)
	 break;
	 for($i=0; $i<12;$i++){
	 if($dat[$j]!=""){
	 $hearders[$i]=$dat[$j];
	 
	 }
	 $j++;
	 }
	 $t++;
	 }
	 
	//echo 'nnnnnnn12';
	
	$r=0;
	$n=2;
	// echo 'nnnnnnn13';
	 while(($data=fgetcsv($handle2, 1000, ","))!=FALSE){
	  $r++;
	//  echo 'nnnnnnn13';
	 if($r==1)
	 continue;
	
	 for($q=0; $q<count($hearders);$q++){
	 if($data[$n]!=""){
	$chechcourses=mysqli_fetch_array(mysqli_query($con,"select * from acd_avalaiblecourses where coursecode='$hearders[$q]'"));
	//echo 'nnnnnnn'.$data[$n];
	$grades=mysqli_fetch_array(mysqli_query($con,"select * from tb_score_grade where value1<=$data[$n] and value2>=$data[$n]"));
	if($chechcourses["courseunit"]!=""){
	$checkrec=mysqli_query($con,"select * from transcript_tblacademics where StduentNumber='$data[0]' and Courseid='{$chechcourses["ID"]}' and semesterid='$semester'  and sessionid='$session'and programid='$course' and levelid='$level' ");
	if(mysqli_num_rows($checkrec)<1){
	$insert=mysqli_query($con,"insert into transcript_tblacademics(StudentNumber,Courseid,semesterid,sessionid,programid,levelid,grade,Scorevalue,points,passid,c_unit,programtype,programcategory)values('$data[0]','{$chechcourses["ID"]}','$semester','$session','$course','$level','{$grades["grade"]}','$data[$n]','{$grades["unitvalue"]}','1','{$chechcourses["courseunit"]}','$protype','$procat')") ;
	 }
	 
	 }
	 }
	$n++;
	
	 }
	 //echo 'hhhhhhh4'.$data[13];
	 $checkrec2=mysqli_query($con,"select * from transcript_tmpsenate where studentnumber='$data[0]' and  semesterid='$semester'  and sessionid='$session'and programid='$course' and levelid='$level' ");
	 
	 if(mysqli_num_rows($checkrec2)<1){
	 $pin=generatePIN(6).GenRanNum();
	
	$insert2=mysqli_query($con,"insert into transcript_tmpsenate(serialno,studentnumber,tcc,tce,tpe,ptcc,ptce,ptpe,ccc,cce,cpe,levelid,programid,sessionid,semesterid,programtype,programcategory,cmf)values('$pin','$data[0]','$data[13]','$data[14]','$data[15]','$data[16]','$data[17]','$data[18]','$data[19]','$data[20]','$data[21]','$level','$course','$session','$semester','$protype','$procat','0')") or die(mysqli_error($con)); 

	 }
	 }
	// print_r( $hearders);
		/// close the final while loop
	 
		//fclose($handle);
	
		if($insert2){
		
		header("Location:previewuploadexam?c=$course&&s=$session&&sem=$semester&&l=$level&&t=$protype&&cat=$procat");
		
		}
	}
	?>
	 
	<h2 align='center'>UPLOAD RESULT</h2>
	 
		<form enctype='multipart/form-data' action='' method='post'>
		<div class="form-group">
															<label for="exampleInputEmail1">
																Programme of Study
															</label>
							<select name="course" class="form-control"   required>
							<option value=""> Select Course </option>
								<?php
								$getcourse = $con->query("SELECT * FROM courselist  order by cosname ASC");
								while($rowcourse = mysqli_fetch_array($getcourse)){
								?>
								<option value="<?php echo $rowcourse['coscode']?>"><?php echo $rowcourse['cosname']?></option>
								<?php
								}
								?>
							</select>
														</div>
														
														
														<div class="form-group">
															<label for="exampleInputEmail1">
																Session
															</label>
							<select name="session" class="form-control"   required>
							<option value=""> Select Session </option>
								<?php
								$getsession = $con->query("SELECT * FROM acd_add_session  order by SessionName ASC");
								while($rowsession = mysqli_fetch_array($getsession)){
								?>
								<option value="<?php echo $rowsession['session_id']?>"><?php echo $rowsession['SessionName']?></option>
								<?php
								}
								?>
							</select>
														</div>
														
														
												<div class="form-group">
															<label for="exampleInputEmail1">
																Program Type
															</label>
							<select name="protype" class="form-control"   required>
							<option value=""> Select Type </option>
								<?php
								$getprotype = $con->query("SELECT * FROM programmes ");
								while($rowprotype = mysqli_fetch_array($getprotype)){
								?>
								<option value="<?php echo $rowprotype['program_id']?>"><?php echo $rowprotype['programme']?></option>
								<?php
								}
								?>
							</select>
														</div>
															   
														
														
											 
													</div>
													
													<div class="col-md-6">
													
													 <div class="form-group">
															<label for="exampleInputEmail1">
																Semester
															</label>
							<select name="semester" class="form-control"   required>
							<option value=""> Select Semester </option>
								<?php
								$getsemester = $con->query("SELECT * FROM acd_semester  order by semestername ASC");
								while($rowsemester = mysqli_fetch_array($getsemester)){
								?>
								<option value="<?php echo $rowsemester['semestercode']?>"><?php echo $rowsemester['semestername']?></option>
								<?php
								}
								?>
							</select>
														</div>
														 
													 <div class="form-group">
															<label for="exampleInputEmail1">
																Level
															</label>
							<select name="level" class="form-control"   required>
							<option value=""> Select Level </option>
								<?php
								$getlevel = $con->query("SELECT * FROM acd_avalaiblelevel  order by levelcode ASC");
								while($rowlevel = mysqli_fetch_array($getlevel)){
								?>
								<option value="<?php echo $rowlevel['id']?>"><?php echo $rowlevel['levelcode']?></option>
								<?php
								}
								?>
							</select>
														</div> 
														
														  <div class="form-group">
															<label for="exampleInputEmail1">
																Program Category
															</label>
							<select name="progcat" class="form-control"   required>
							<option value=""> Select Category </option>
								<?php
								$getprocat = $con->query("SELECT * FROM program_category ");
								while($rowprocat = mysqli_fetch_array($getprocat)){
								?>
								<option value="<?php echo $rowprocat['prog_cat_id']?>"><?php echo $rowprocat['prog_cat_name']?></option>
								<?php
								}
								?>
							</select>
							</div>
	 
	 <div class="form-group">
															<label for="exampleInputEmail1">
																Select File
															</label>
	 
		<input size='50' type='file' name='filename'><br />
		</div>
	 
	  <input type='submit' name='upload' value='Upload'>
	  </form>
	 
 </div>   
													</div>
													</div>
													
													
													
														
						</div>
						
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>

<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
	$('#table_id').DataTable();
			} );
		</script>
</body>
</html>
