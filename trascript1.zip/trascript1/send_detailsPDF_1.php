<?php
ob_start();
ini_set('display_errors', 'on');
include('include/config.php');
//include('include/checklogin.php');
require('fpdf.php');
ini_set("max_execution_time", 0);
//session_start();

class PDF extends FPDF
{

function Footer()
{
    $this->SetY(-15);  $this->SetFont('Arial','I',8); $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function RotatedText($x, $y, $txt, $angle)
{
$this->Rotate($angle,$x,$y);  $this->Text($x,$y,$txt);  $this->Rotate(0);
}
function RotatedImage($file,$x,$y,$w,$h,$angle)
{
$this->Rotate($angle,$x,$y); 
$this->Image($file,$x,$y,$w,$h); $this->Rotate(0);
}

function myHeader(){
$this->SetLeftMargin(10);
$this->SetFont('Arial','B',14); 
//$this->Image('images/logo.png',5,0.5,20,20);
//$this->Image('images/bsulogo2.jpg',5,0.5,20,20);
$this->Cell(30,3,'',0,0,'L',false);
$this->Cell(120,20,'JOSEPH SARWUAN TARKA UNIVERSITY, MAKURDI',0,0,'L',false);
$this->Ln();
$this->Cell(60,3,'',0,0,'L',false);
$this->Cell(120,1,'(Office of the Registrar)',0,0,'L',false);

}

function lgos(){
$this->SetLeftMargin(10);
$this->SetFont('Arial','B',16); 


$this->Ln();
$this->Cell(120,5,$this->Image('logo1.png',80,35,30,30),0,0,'L',false);
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
$this->Cell(50,3,'',0,0,'L',false);
$this->Cell(100,3,'ACADEMIC TRANSCRIPT',0,0,'L',false);
$this->Ln();
$this->Ln();
$this->Ln();
$this->Cell(60,3,'',0,0,'L',false);
$this->Cell(120,1,'(For external use only)',0,0,'L',false);
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
$this->Ln();
}

function WriteStudentDetails($details)
{

$this->SetFont('Arial','B',36); 
$this->SetTextColor(230); 
$this->SetFillColor(240); 
//$this->RotatedText(8,190,'JOSEPH SARWUAN TARKA UNIVERSITY, MAKURDI',45);
//$this->Image('images/logo.png',5,0.5,20,20);

 
 $this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(150,5,'CANDIDATE DETAILS',1,0,'C',false);
$this->Ln();
$this->Cell(60,5,'Full Name(Surname First):',1,0,'L',false);
$this->Cell(90,5,$details[0],1,0,'L',false);
$this->Ln();
$this->Cell(60,5,'Student Number',1,0,'L',false);
$this->Cell(90,5,$details[1],1,0,'L',false);
$this->Ln();
$this->Cell(60,5,'Memebers Mobile Number',1,0,'L',false);
$this->Cell(90,5,$details[2],1,0,'L',false);
$this->Ln();
$this->Cell(60,5,'DATE OF BIRTH :',1,0,'L',false);
$this->Cell(90,5,$details[3],1,0,'L',false);
$this->Ln();
$this->Cell(60,5,'Memebers Gender:',1,0,'L',false);
$this->Cell(90,5,$details[4],1,0,'L',false);

$this->Ln();
$this->Cell(60,5,'Registration Date:',1,0,'L',false);
$this->Cell(90,5,$details[5],1,0,'L',false);

$this->Ln();
$this->Ln();
$this->Ln();

}

function acaddetail($acad){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(195,5,'ACADEMIC DETAILS:',1,0,'L',false);
$this->Ln();
$this->Cell(40,5,'Course/specialization:',1,0,'L',false);
$this->Cell(40,5,'Department',1,0,'L',false);

$this->Cell(40,5,'College',1,0,'L',false);
$this->Cell(30,5,'Session Admitted',1,0,'L',false);
$this->Cell(30,5,'Session Graduated',1,0,'L',false);
$this->Cell(15,5,'Status',1,0,'L',false);

$this->Ln();
 

$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(40,5,$acad[0],1,0,'L',false);
$this->Cell(40,5,$acad[1],1,0,'L',false);


$this->Cell(40,5,$acad[2],1,0,'L',false);
$this->Cell(30,5,$acad[3],1,0,'L',false);
$this->Cell(30,5,$acad[4],1,0,'L',false);
$this->Cell(15,5,$acad[5],1,0,'L',false);
$this->Ln();
 $this->Ln();
}





function semyear($semn){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(30,5,'LEVEL:',0,0,'L',false);
$this->Cell(30,5,$semn[0],0,0,'L',false);

$this->Cell(30,5,'YEAR: ',0,0,'L',false);
$this->Cell(30,5,$semn[1],0,0,'L',false);
$this->Cell(30,5,'SEMESTER: ',0,0,'L',false);
$this->Cell(30,5,$semn[2],0,0,'L',false);
 $this->Ln();
}


function courseHeader1(){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(25,5,'COURSE CODE:',1,0,'L',false);
$this->Cell(75,5,'COURSE TITLE',1,0,'L',false);

$this->Cell(15,5,' UNITS',1,0,'C',false);
$this->Cell(15,5,' GRADE',1,0,'C',false);
$this->Cell(25,5,'GRADE POINT ',1,0,'L',false);
$this->Cell(40,5,'WEIGHTED GRADE POINT',1,0,'L',false);
 $this->Ln();
}

function currentsemdetails($curd){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(25,5,'TCC: '.$curd[0],0,0,'L',false);
$this->Cell(25,5,'TCE  '.$curd[1],0,0,'L',false);

$this->Cell(20,5,' TPE:  '.$curd[2],0,0,'C',false);
$this->Cell(20,5,' GPA:  '.$curd[3],0,0,'C',false);
$this->Cell(25,5,'CCC:   '.$curd[4],0,0,'L',false);
$this->Cell(30,5,'CCE:  '.$curd[5],0,0,'L',false);
$this->Cell(25,5,'CPE:  '.$curd[6],0,0,'L',false);
$this->Cell(30,5,'CGPA:  '.$curd[7],0,0,'L',false);
 $this->Ln();
 $this->Ln();
 $this->Ln();
}


function courseHeader($deta){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(70,5,'LEVEL:  '.$deta[0],0,0,'L',false);


$this->Cell(60,5,' YEAR: '.$deta[1],0,0,'C',false);


$this->Cell(45,5,$deta[2],0,0,'L',false);
 $this->Ln();
}




function courselist($list){
$this->SetFont('Arial','',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(25,5,$list[0],0,0,'L',false);
$this->Cell(75,5,$list[1],0,0,'L',false);

$this->Cell(15,5,$list[2],0,0,'C',false);
$this->Cell(15,5,$list[3],0,0,'C',false);
$this->Cell(25,5,$list[4],0,0,'C',false);
$this->Cell(40,5,$list[5],0,0,'C',false);
$this->Ln();

}

function sumweightedgp($weight){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(30,5,'',0,0,'L',false);
$this->Cell(30,5,'',0,0,'L',false);

$this->Cell(30,5,'',0,0,'L',false);
$this->Cell(30,5,'',0,0,'L',false);
$this->Cell(30,5,'',0,0,'L',false);
$this->Cell(30,5,'WGP : '.$weight[0],0,0,'L',false);
$this->Ln();
}


function gradingheader(){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(30,5,'SCORE',1,0,'L',false);
$this->Cell(30,5,'LETTER',1,0,'L',false);
$this->Cell(30,5,'GRADE',1,0,'L',false);
$this->Ln();
}
function gradings($grad){
$this->SetFont('Arial','',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(30,5,$grad[0],1,0,'L',false);
$this->Cell(30,5,$grad[1],1,0,'L',false);
$this->Cell(30,5,$grad[2],1,0,'L',false);
$this->Ln();
}
function classofdegreeheader(){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->SetXY(120,$this->GetY()-35);

$this->Cell(30,5,'CGPA',1,0,'L',false);
$this->Cell(30,5,'CLASS OF DEGREE',1,0,'L',false);

$this->Ln();
}

function classofdegree($clas){
$this->SetFont('Arial','',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->SetX(120);
$this->Cell(30,5,$clas[0],1,0,'L',false);
$this->Cell(30,5,$clas[1],1,0,'L',false);
$this->Ln();
}



function semsummary($semt){
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(30,5,'CUR:     '.$semt[0],0,0,'L',false);
$this->Cell(30,5,'CUR :    '.$semt[1],0,0,'L',false);

$this->Cell(30,5,'TWGP :   '.$semt[2],0,0,'L',false);
$this->Cell(30,5,'GPA :    '.$semt[3],0,0,'L',false);
$this->Cell(30,5,'CGPA:    '.$semt[4],0,0,'L',false);
$this->Ln();

}


function signaturedean($dean){
$this->Ln();
$this->Ln();
$this->Ln();
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->Cell(40,5,$this->Image('stamps/'.$dean[0],15,60,20,20),0,0,'L',false);
$this->Ln();
$this->Cell(40,5,$dean[1],0,0,'L',false);
$this->Ln();
$this->Cell(30,5,'(COLLEGE DEAN)',0,0,'L',false);
$this->Ln();
}

function signaturesec($sec){
$this->Ln();
$this->Ln();
$this->Ln();
$this->SetFont('Arial','B',8);
 $this->SetTextColor(0); 
$this->SetLineWidth(.3);
$this->SetXY(120,$this->GetY()-16);
$this->Cell(30,5,$this->Image('stamps/'.$sec[0],120,60,20,20),0,0,'L',false);
$this->Ln();
$this->SetXY(120,$this->GetY()-10);
$this->Cell(40,5,$sec[1],0,0,'L',false);
$this->Ln();
$this->SetXY(120,$this->GetY()-0);
$this->Cell(30,5,'(COLLEGE SECRETARY)',0,0,'L',false);
$this->Ln();
}



}

$matno = $_GET['viewid'];


$pdf = new PDF(); 
 $pdf->AddPage();
$pdf-> myHeader();
$pdf->lgos();

//$pdf->acaddetailsheaders();

 $ret=mysqli_query($con,"select * from users u join courselist t ON(u.ProgramID=t.coscode) join acd_avalaiblelevel v ON(v.id=u.graduatedLevelID) join acd_department d ON(d.deptcode=u.deptID) join faculties f ON(d.faccode=f.faccode) join acd_add_session s ON(s.session_id=u.SessionGraduatedID) where u.user_ID='$matno' LIMIT 1");
 $row=mysqli_fetch_array($ret);
 
 $details[0]=$row['fullName'];
 $details[1]=$row['user_ID'];
 $details[2]=$row['phoneNo'];
 $details[3]=$row['address'];
 $details[4]=$row['gender'];
 $details[5]=$row['regDate'];
 
 $pdf->WriteStudentDetails($details);
 
 
  $acad[0]= $row['cosname'];
  $acad[1]= $row['deptname'];
  $acad[2]= $row['facname'];
  $acad[3]= $row['SessionAdmittedID'];
  $acad[4]=$row['SessionName']; 
  $acad[5]= $row['graduateStus']; 
 
 
$pdf->acaddetail($acad);
 /*
$studentdetails=Rfetch(Execute("select * from student where StudentNumber='$matno' "));
 $details[0]=$studentdetails["Surname"]."  ".$studentdetails["MiddleName"]."  ".$studentdetails["FirstName"];
 $details[1]=$matno;
 $details[2]=$studentdetails["DateOfBirth"];
 $details[3]=$studentdetails["Sex"];
 $dept=Rfetch(Execute("select * from department where idDepartment='{$studentdetails["Department_idDepartment"]}'"));
 $faculty=Rfetch(Execute("select * from faculty where idFaculty ='{$dept["Faculty_idFaculty"] }' "));  
 $details[5]=$faculty["FacultyName"];
 $details[6]=$dept["Name"];
 $deg=Rfetch(Execute("select * from degree where idDegree='{$studentdetails["Degree_idDegree"]}'")); 
$details[7]=$deg["DegreeinView"];

 $details[8]=ClassDoDegree($matno);
 


 $level=Execute("select * from level order by idLevel ASC");
 */
   $twgpa=0;
  $totalweightedgp=0;
  $totaunitsEarn=0;
  $totalUnitsRegisterd=0;
 
 $getlevels = mysqli_query($con,"SELECT DISTINCT sessionid,levelid FROM transcript_tmpsenate WHERE StudentNumber = '$matno' ORDER BY levelid ASC ");
	 while($readlevel = mysqli_fetch_array($getlevels)){
		 $mysession = $readlevel['sessionid'];
		 $levelid = $readlevel['levelid'];
		 $sessiondetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_add_session WHERE session_id = $mysession"));
		 
		 $leveldetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_avalaiblelevel WHERE id = $levelid"));
		 
		$getsemesterid = mysqli_query($con,"SELECT DISTINCT semesterid FROM transcript_tmpsenate WHERE StudentNumber = '$matno' ORDER BY semesterid ASC");
		
	 while($readsemesterid = mysqli_fetch_array($getsemesterid)){
		 $semesterid = $readsemesterid['semesterid']; 
		 
		 $semesterdetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM acd_semester WHERE semestercode = $semesterid"));
		 
		 
		 $deta[0]=$leveldetails['levelcode'];
		 $deta[1]=$sessiondetails['SessionName'];
		 $deta[2]=$semesterdetails['semestername'];
		 
		 $pdf->courseHeader($deta);
		 
		 $pdf->courseHeader1();
		  
		 $semunitsregistered=0;
		$semunitsearned=0;
		$semwightedpoints=0;
		$datafor_result = mysqli_query($con,"select * from transcript_tblacademics t JOIN acd_avalaiblecourses c ON(c.ID=t.CourseID) WHERE t.StudentNumber = '$matno' AND  t.sessionid = '$mysession' AND t.semesterid = '$semesterid' AND t.levelid='$levelid'") ;

while($getdate = mysqli_fetch_array($datafor_result)){
	$cosecode = $getdate['coursecode'];
	 $cosetitle = $getdate['coursetitle'];
	 $crditunit = $getdate['c_unit'];
	 $Points = $getdate['points'];
	 $grade = $getdate['grade'];
	 
	 $gradepoints = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM tb_score_gradehistory WHERE sessions = $mysession AND grade = '$grade' ")); 
	 $intvalpoint = $gradepoints['unitvalue'];
	 
	 $weightpoints = $crditunit * $Points ;
	 
	 $list[0]=$cosecode;
	  $list[1]=$cosetitle;
	  $list[2]=$crditunit;
	  $list[3]=$grade;
	  $list[4]=$Points;
	 $list[5]=$weightpoints;
	  $semunitsregistered+=$crditunit;
	  if($Points>0){
		$semunitsearned+=$crditunit;
		}
		$semwightedpoints+=$weightpoints;
	 
	
	 
    $pdf->courselist($list);
	
	}
	
	 $totalUnitsRegisterd+=$semunitsregistered;
	 $totaunitsEarn+=$semunitsearned;
	 $totalweightedgp+=$semwightedpoints;
	 $curd[0]= $semunitsregistered;
	 $curd[1]=$semunitsearned;
	 $curd[2]=$semwightedpoints;
	 $curd[3]=number_format($semwightedpoints/$semunitsregistered,2);
	 $curd[4]= $totalUnitsRegisterd;
	 $curd[5]= $totaunitsEarn;
	 $curd[6]= $totalweightedgp;
	 $curd[7]=number_format($totalweightedgp/$totalUnitsRegisterd,2);
	 
	$pdf->currentsemdetails($curd);
	}


	}
	
	
	$pdf->gradingheader();
	
	$getgradingsystem = mysqli_query($con, "SELECT * FROM tb_score_grade ");
	 while($readgrade = mysqli_fetch_array($getgradingsystem)){
	$grad[0]=$readgrade['value1']." - ".$readgrade['value2'];
	$grad[1]=$readgrade['grade'];
	$grad[2]=$readgrade['unitvalue'];
	
	$pdf->gradings($grad);
	
	}
	
	$pdf->classofdegreeheader();
	$getcgpa = mysqli_query($con, "SELECT * FROM acd_cgpagradingsystem ");
	 while($readcgpa = mysqli_fetch_array($getcgpa)){
	 $clas[0]=number_format($readcgpa['lowercgpa'],2)." - ".number_format($readcgpa['highercgpa'],2);
	 $clas[1]= $readcgpa['classofdegreedescription'];
	$pdf->classofdegree($clas);
	}
	
	
	
	$deansig=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transdeansignatory where assginStatus='1'"));
	$dean[0]=$deansig["stampURL"];
	$dean[1]=$deansig["staffName"];
	$pdf->signaturedean($dean);
	
	$secsig=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transsecsignatory where assignStatus='1'"));
	$sec[0]=$secsig["stampURL"];
	$sec[1]=$secsig["staffName"];
	$pdf->signaturesec($sec);
	
 $pdf->Output();
  ob_end_flush();
 
?>
