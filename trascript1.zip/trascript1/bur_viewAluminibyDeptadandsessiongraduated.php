<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
//check_login();



?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
    <script>
// Popup window code
function newWindow(url) {
	popupWindow = window.open(
		url,
		'popUpWindow','height=600,width=700,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
	<body>
		<div id="app">		
<?php include('include/bursarsidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h3 class="mainTitle">Admin | View Alumini by Department and Session Graduated</h3>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>View by Department and session graduated </span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						
								

								<p style="color:red;"><?php echo htmlentities($_SESSION['msg']);?>
								<?php echo htmlentities($_SESSION['msg']="");?></p>	
													<div class="rows">
													<div class="col-md-6">
													<form role="form" name="dcotorspcl" method="post" >
														<div class="form-group">
															<label for="exampleInputEmail1">
																Department
															</label>
							<select name="dept" class="form-control"   required>
							<option value=""> Select Department </option>
								<?php
								$deptname;
								$getdept = $con->query("SELECT * FROM acd_department  order by deptname ASC");
								while($rowcourse = mysqli_fetch_array($getdept)){
								?>
								<option value="<?php echo $rowcourse['deptcode']?>"><?php echo $rowcourse['deptname']?></option>
								<?php
								}
								?>
							</select>
														</div>
                                          <div class="form-group">
															<label for="Session">
																Session Graduated
															</label>
							<select name="session" class="form-control"   required>
							<option value=""> Select Session </option>
								<?php
								$getsession = $con->query("SELECT * FROM acd_add_session  order by SessionName ASC");
								while($rowsession = mysqli_fetch_array($getsession)){
								?>
								<option value="<?php echo $rowsession['session_id']?>"><?php echo $rowsession['SessionName']?></option>
								<?php
								}
								?>
							</select>
														</div>
                                                                      
                                                       <button type="submit" name="submit" class="btn btn-o btn-primary">
															Submit
														</button>
                                                        
                                                        </div>
                                                        
													</form>
                                                    </div>   
													</div>
													</div>
													<br/> <br/>
													
										<?php 


										if(isset($_POST["dept"])){
										$dept=$_POST["dept"];
										$getdeptname = $con->query("SELECT deptname FROM acd_department  where deptcode='$dept'");
								while($rowcourse = mysqli_fetch_array($getdeptname)){
						$deptname=$rowcourse['deptname'];
								
								}}
								if(isset($_POST["session"])){
								$sessiongraduatedid = $_POST["session"]; 
$getsessiongraduated = $con->query("SELECT SessionName FROM acd_add_session  where session_id='$sessiongraduatedid'");
								while($rowcourse = mysqli_fetch_array($getsessiongraduated)){
						$Sessiongraduated=$rowcourse['SessionName'];
								
								}	
								?>

									<div class="row">
								<div class="col-md-12 table-responsive">
									<h5 class="over-title margin-bottom-15"><span class="text-bold">List of all  alumini from  <?php echo $deptname;?>  Dpartment graduated in <?php echo $Sessiongraduated;?> Session </span></h5>
									<table class="table table-hover" id="table_id">
										<thead>
											<tr>
                                          
												<th class="center">Sno</th>
												<th>MAT NO</th>
												<th class="hidden-xs">NAME </th>
												<th>ADDRESS </th>
												<th>CITY </th>
												<th>GENDER</th>
                                                <th>PHONE NUMBER</th>
                                                <th>PROGRAM</th>
                                                <th>SESSION ADMITED</th>
                                               
											</tr>
										</thead>
										<tbody>
<?php
//echo "select * from transcript_tmpsenate where programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat'";
$sql = mysqli_query($con,"select * from users where deptID='$dept' and SessionGraduatedID='$sessiongraduatedid'");
$cnt=1;
while($row=mysqli_fetch_assoc($sql))
{
$proramid =$row['ProgramType'];
$programname;
$getproramname = $con->query("SELECT programme FROM programmes  where program_id='$proramid'");
								while($rowcourse = mysqli_fetch_array($getproramname)){
						$programname=$rowcourse['programme'];
								
								}
								
$sessionadmintedid = $row['SessionAdmittedID'];
$getsessionadmited = $con->query("SELECT SessionName FROM acd_add_session  where session_id='$sessionadmintedid'");
								while($rowcourse = mysqli_fetch_array($getsessionadmited)){
						$SessionAdmitted=$rowcourse['SessionName'];
								
								}

?>

											<tr>
												<td><?php echo $row['id'];?></td>
												<td><?php echo $row['user_ID'];?></td>
                                                
												<td><?php echo $row['fullName'];?></td>
												<td><?php echo $row['address'];?></td>
                                               <td><?php $gpa=$row['city']/$row['tcc'];  echo number_format($gpa,2);?></td>
                                                
												<td><?php echo $row['gender'];?></td>
                                                <td><?php echo $row['phoneNo'];?></td>
                                                <td><?php echo $programname;?></td>
                                                <td><?php echo $SessionAdmitted;?></td>
											
                                            </tr>
											
											<?php 
									$cnt=$cnt+1;
											 //}
												}
											 ?>
											
											
										</tbody>
									</table>
								</div>
							</div>
                            <?php } ?>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		
  

		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
    $('#table_id').DataTable();
			} );
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
