<?php 
session_start();
require 'remita_constants.php';
//require 'remita_constants_demo.php';
include('include/config.php');
include('include/checklogin.php');
check_login2();
 $userid = $_SESSION['id'];
$msg = "";
$orderID = "";
$trandatedate = date("Y-m-d h:i:s");
if( isset( $_GET['orderID'] )) {
$orderID = $_GET["orderID"];
}
//$orderID = "aXKJO4ng0e448026165";
$response_code =""; $rrr = ""; $response_message = ""; $transactiontime = "" ;
//Verify Transaction
function remita_transaction_details($orderId){
		$mert =  MERCHANTID;
		$api_key =  APIKEY;
		$concatString = $orderId . $api_key . $mert;
		$hash = hash('sha512', $concatString);
		$url 	= CHECKSTATUSURL . '/' . $mert  . '/' . $orderId . '/' . $hash . '/' . 'orderstatus.reg';
		//  Initiate curl
		$ch = curl_init();
		// Disable SSL verification
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		// Will return the response, if false it print the response
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// Set the url
		curl_setopt($ch, CURLOPT_URL,$url);
		// Execute
		$result = curl_exec($ch);
		// Closing
		curl_close($ch);
		$response = json_decode($result, true);
		return $response;
	}
	
	if($orderID !=null){
		$response = remita_transaction_details($orderID);
		$response_code = $response['status'];
		$transactiontime = $response['transactiontime'];
		$amount = $response['amount'];
		//echo $response_code;
		if (isset($response['RRR']))
			{
			$rrr = $response['RRR'];
			}
		$response_message = $response['message'];
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////




if ($orderID !="" && $rrr !="") // || isset($_GET['txn']))
{ 


	//$respc='00'; here transaction was successful

	if ($response_code=="00" || $response_code=="01")
	{
		$con->begin_transaction();
		
		mysqli_query($con,"UPDATE transaction_details_logs SET trans_ref_no = '$rrr', reponseCode = '$response_code', reponseMessage = '$response_message' , companyBank = 'Remita Pay', companyAccount = '0180474861013', paymentMethod = 'Remita Pay', dateConfirmed = '$transactiontime', trans_status = 'confirmed', confirm_payment ='0',usedStatus = 'Open'  WHERE tran_ID = '$orderID' ");
		
		$getpaydetails = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type) WHERE p.tran_ID = '$orderID' "));
		$fullname = $getpaydetails['Fullname'];
		$matno = $getpaydetails['userID'];
		$typeDescription = $getpaydetails['paymentype'];
		//$sessionid = $getpaydetails['sessionid'];
		//$semesterid = $getpaydetails['semesterid'];
		$paytype = $getpaydetails['paymentype'];
		
		$invoice = mysqli_num_rows(mysqli_query($con,"SELECT * FROM transaction_details_logs WHERE tran_ID = '$orderID' and confirm_payment = 'confirmed'"));
		if($invoice<1){
			mysqli_query($con,"DELETE FROM transaction_details WHERE tran_ID = '$orderID' and confirm_payment = 'confirmed' AND confirm_payment ='0'");
			mysqli_query($con,"INSERT INTO transaction_details SELECT * FROM transaction_details_logs WHERE tran_ID = '$orderID'");
			
			mysqli_query($con,"INSERT INTO request_transcript(appNo,StudentNumber,FullName,DateApp,PurposeApp,CloseDate) 
	VALUES('$orderID','$matno','$fullname','$trandatedate','$paytype','Open')");
			}
			
		
		
		
		$con->commit();

	$msg1 ="Dear $fullname ($matno). <p> Your $typeDescription transaction was successful. <p> <a href='print_receipt?txn=".$orderID."' taget='_blank'>Click on print receipt</a>";
	
$msg = '<div class="alert alert-success alert-dismissible">
							
					  <strong>Success! </strong> '.$msg1.'.
							</div>';
	}
	else
	{
		$fullname = ""; $matno = ""; $typeDescription = "";
		//$con->query("update pay_main_transaction set  PaymentRespCode= '022',RRRstatus = '$statuscode',statusMessage = '$statusMsg' WHERE trainId= '$transid'");
		/////////////////////////////////////////////////////////////////////////////////////////
	$msg1 ="Dear $fullname ($matno). <p> Your $typeDescription transaction was  failed. <p> Reason: $response_message. ";
	$msg = '<div class="alert alert-danger alert-dismissible">
							
					  <strong>Error! </strong> '.$msg1.'.
							</div>';
	}
	 
}
//echo "SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type)  WHERE p.tran_ID = '$orderID' ";
$getcheck = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type)  WHERE p.tran_ID = '$orderID' "));
$rrrstatus = $getcheck['RRRStatus'];
$confirmstatus = $getcheck['trans_status'];
$dbRRR = $getcheck['trans_ref_no'];
if ($rrrstatus!="025" && $dbRRR=="0"){ 
$incomplete = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type) WHERE p.tran_ID = '$orderID' "));
	$con->query("UPDATE transaction_details_logs SET trans_status = '4' WHERE trainId = '$orderID' ");
$msg1 ="Dear ".$incomplete['Fullname'] ." (".$incomplete['userID']."). <p> Your ".$incomplete['paymentype']." transaction was  unable to generate RRR. <p> Reason: Incomplete Transaction, Try it Again please. ";
	$msg = '<div class="alert alert-warning alert-dismissible">
						
					  <strong>Notice! </strong> '.$msg1.'.
							</div>';
}
if ($rrrstatus=="025" && $dbRRR==$rrr && $confirmstatus == "0")
{
	$card='<img src="images/online.png" style="cursor:pointer" onClick="return view_client()" width="270" height="65">';
	$link="print_rrr?txn=$orderID"; echo "<script>page='$link'</script>";
	$bank ='<img src="images/bank.png" style="cursor:pointer" width="270" height="65" onClick="return pt(page)">'; 
	$incomplete1 = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type) WHERE p.tran_ID = '$orderID' "));
	$msg1 ="Dear ".$incomplete1['Fullname'] ."(".$incomplete1['userID']."). <p> Your ".$incomplete1['paymentype']." transaction RRR was  Generated. Please you can download it to pay in the Bank <br> ".$bank." ".$card." ";
	$msg = '<div class="alert alert-warning alert-dismissible">
							
					  <strong>Notice! </strong> '.$msg1.'.
							</div>';
	
	//$img = "<img  style='cursor:pointer' src='../images/print.png' width='162' height='46' alt='Print'>	";
}
$merchant= MERCHANTID;
$responseurl ="http://3.233.182.34/replyrespons.php";
//$responseurl ="http://localhost/replyrespons.php";
$rrr = trim($response['RRR']);
$new_hash_string = MERCHANTID . $rrr . APIKEY;
$new_hash = hash('sha512', $new_hash_string);
 ?>
<html>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>User | Enter Bank Details</title>
		
		<!--<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />-->
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />


	</head>
	<body>
		<div id="app">		
<?php include('include/sidebar1.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
						
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">

                    <div class="main-page">
                        <div class="container-fluid">
                            <div class="row page-title-div">
                                <div class="col-md-6">
                                    <h2 class="title">Payment Information</h2>
                                
                                </div>
								
								<form name="SubmitRemitaForm" enctype="application/x-www-form-urlencoded" method="post" action="https://login.remita.net/remita/ecomm/finalize.reg">

								
								<input id="merchantId" name="merchantId" value="<?php echo $merchant; ?>" type="hidden"/>
								<input id="rrr" name="rrr" value="<?php echo $rrr; ?>" type="hidden"/>
								<input id="responseurl" name="responseurl" value="<?php echo $responseurl; ?>" type="hidden"/>
								<input id="paymenttype" name="paymenttype" value="VERVE" type="hidden"/>                
								<input id="hash" name="hash" value="<?php echo $new_hash; ?>" type="hidden"/>
								</form>
                                
                                <!-- /.col-md-6 text-right -->
                            </div>
                            <!-- /.row -->
                            <div class="row breadcrumb-div">
                                <div class="col-md-6">
                                    <ul class="breadcrumb">
            							
            							<li class="active">Payment Information</li>
            						</ul>
                                </div>
                             
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->

                        <section class="section">
                            <div class="container-fluid">

                             
							
                                <div class="row">
                                    <div class="col-md-12">

                                        <div class="panel">
                                             <div class="panel-body p-20">
											 
                                               <div class="row">
											   <div class="text-center"><?php echo $msg ?></div>
											   </div>
                                                <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered table-striped" >
                             
								<!---<p><a href="add_prog.php" class="btn btn-success"><i class="icon-plus"></i>&nbsp;Add Courses of Study</a></p>-->
							
                                <thead>
                                    <tr>
                       
                                        <th>FullName</th>
										<th>Invoice Description</th>										
                                        <th>Amount</th>
										
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php  
                                  $n=0;
			//echo $ddi = $SemesterID2." ".$program." ".$studytype." ".$collegename;					  
                                   $feetype = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs p JOIN payment_type t ON(t.id=p.entry_Type) WHERE p.tran_ID = '$orderID' "));
								   
                                   
                                    ?>
									<tr class="">
									
                                    <td><?php echo $feetype['Fullname']; ?></td>	
									<td class=""><?php echo $feetype['paymentype']; ?></td> 									
                                    <td class=""><?php echo number_format($feetype['transactionAmount']); ?></td> 
									
                                    </tr>
									
                           
                                </tbody>
                            </table>
                                         
                                                <!-- /.col-md-12 -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-6 -->

                                                               
                                                </div>
                                                <!-- /.col-md-12 -->
                                            </div>
                                        
                            <!-- /.container-fluid -->
                        </section>
                        <!-- /.section -->
						
                    </div>
                    <!-- /.main-page -->

                    

                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->

        </div>
        <!-- /.main-wrapper -->

        <!-- ========== COMMON JS FILES ========== -->
        <?php //include('includes/htnlFooter.html'); ?>
		<?php //include("commons/web-commons.php") ; ?>
		<?php //include("commons/select-commons.php") ; ?>
        
    </body>
</html>
<script language ="javascript">
function view_client() {
	document.SubmitRemitaForm.submit();
}
function pt(page)
{
	//window.close();
	window.open(page, "CtrlWindow", "width=1200,height=800,toolbar=no,menubar=yes,location=no,scrollbars=no,resize=no")
	
	}
</script>