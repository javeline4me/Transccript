<?php
session_start();
include('include/config.php');
include('include/checklogin.php');
$txn = $_GET['txn'];

$getschoolinfo = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM school_info "));
$stchools = $getschoolinfo['schlname'];
$schoolAddree = $getschoolinfo['pobox'].", ".$getschoolinfo['address'];

$getrecords = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs WHERE tran_ID = '$txn' "));
$rrr = $getrecords['trans_ref_no'];
$name = $getrecords['Fullname'];
$regno = $getrecords['userID'];
$amount = number_format($getrecords['transactionAmount'],2);
$feeType = $getrecords['entry_Type'];
$getfeetype = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM payment_type WHERE id = '$feeType' "));
$paytypename = $getfeetype['paymentype'];
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
	<style>
body {
        margin: 0;
        padding: 0;
        background-color: #FAFAFA;
        font: 12pt "Tahoma";
    }
    * {
        box-sizing: border-box;
        -moz-box-sizing: border-box;
    }
    .page {
        width: 21cm;
        min-height: 29.7cm;
        padding: 2cm;
        margin: 1cm auto;
        border: 1px #D3D3D3 solid;
        border-radius: 5px;
        background: white;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
    .subpage {
        padding: 1cm;
        border: 5px red solid;
        height: 256mm;
        outline: 2cm #FFEAEA solid;
    }
    
    @page {
        size: A4;
        margin: 0;
    }
    @media print {
        .page {
            margin: 0;
            border: initial;
            border-radius: initial;
            width: initial;
            min-height: initial;
            box-shadow: initial;
            background: initial;
            page-break-after: always;
        }
    }
div.b {
  line-height: 1.6;
}

</style>
         <?php include('include/headerscript.html'); ?>
    </head>
    <body>
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
  <?php //include('includes/topbar.php');?> 
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->
                   <?php //include('includes/leftbarStudents.php');?>  
                    <!-- /.left-sidebar -->

                    <div class="main-page">

                    
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                           
                                            <div class="panel-body">
							
													<div class="bs-exp">
												<div class="col-md-4 text-center">
												<button class="btn btn-default" onclick="printDiv('printableArea')"><i class="fa fa-print" aria-hidden="true" style="    font-size: 17px;"> Print</i></button>
												</div>
											<div class = "page" id="printableArea"><!-- Start Print -->
											<div align="center">
											<h2><?php echo $stchools ?></h2>
											<p align="center"> <img src="<?php echo "images/Untitled3.png" ?>" width="10%" height="10%" class="img-responsive"></p>
											  <h2><?php echo $schoolAddree ?></h2>
											  <p>Direct Bank Payment Details with transaction ID: <?php echo $txn ?></p>
												</div>
												<br/>
												<div class="table-responsive" align="center">
											  <table class="table table-bordered">
												<thead>
												  <tr>
													<th>Reg. No</th>
													 <td><?php echo $regno ?></td>
												  </tr>
												  <tr>
												   
													<th>Student FullName</th>
													<td><?php echo $name ?></td>
												  </tr>
												  <tr>
												   
													<th>RRR</th>
													  <td><?php echo $rrr ?></td>
												  </tr>
												  <tr>
													
													 <th>Amount</th>
													  <td><?php echo $amount ?></td>
												  </tr>
												  <tr>
													
													 <th>Payment Type</th>
													  <td><?php echo $paytypename ?></td>
												  </tr>
												</thead>
												<!--
												<tbody>
												  <tr>
													
													 <td>john@example.com</td>
												  </tr>
												 
												</tbody>
												-->
											  </table>
											</div>
												
										</div><!-- print ends here -->
        
												</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                </div>
								
                    </div>
                </div>
                <!-- /.content-container -->
            </div>
            <!-- /.content-wrapper -->
        </div>
        <!-- /.main-wrapper -->
        <?php //include('includes/htnlFooter.html'); ?>
		</body>
		<script type="text/javascript">  
      
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
</html>

