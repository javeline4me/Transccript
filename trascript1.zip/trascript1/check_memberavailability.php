<?php 
require_once("include/config.php");
if(!empty($_POST["usernames"])) {
	$usernames= $_POST["usernames"];
	
		$result =mysqli_query($con,"SELECT UserName FROM alumni_account WHERE UserName='$usernames'");
		$count=mysqli_num_rows($result);
if($count>0)
{
echo "<span style='color:red'> UserName Choose already exists .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else{
	
	echo "<span style='color:green'> UserName Choose is available for Registration .</span>";
 echo "<script>$('#submit').prop('disabled',false);</script>";
}
}


?>
