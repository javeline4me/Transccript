	<?php
	session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
//check_login();
$ms ="Transcript Record Confirmed successfully";
 //echo $_SESSION["matno"] ;
 
		$viewid=$_SESSION["matno"];
		
	if(isset($_POST["confirm"])){


$update=mysqli_query($con,"UPDATE users  SET confirmTranscript='1' WHERE user_ID='$viewid' ") or die(mysqli_error($con));
if($update>0)
    echo $ms;
    //header("Refresh:0");
}



	?>
<!DOCTYPE html>
<html lang="en">
	<body>
		<h2>  		<?php  echo $ms;
		//echo "<script>window.location.href ='panding_application' </script>";
	 ?>
		</h2>
       	
         <form role="form" name="dcotorspcl" method="post" >
								
<table class="table table-hover" id="table_id">
										<thead>
											<tr>
                                          
												<th class="center">Sno</th>
												<th>MAT NO</th>
												<th class="hidden-xs">NAME </th>
												<th>ADDRESS </th>
												<th>CITY </th>
												<th>GENDER</th>
                                                <th>PHONE NUMBER</th>
                                                <th>PROGRAM</th>
                                                <th>SESSION ADMITED</th>
                                                <th>SESSION GRADUATED</th>
                                               
											</tr>
										</thead>
										<tbody>
<?php
//echo "select * from transcript_tmpsenate where programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level' and programtype='$protype' and programcategory='$procat'";
$sql = mysqli_query($con,"select * from users where `user_ID`='$viewid'");
$cnt=1;
while($row=mysqli_fetch_assoc($sql))
{
	//$proramid =$row['ProgramType'];
$proramid =$row['ProgramType'];
$programname;
$getproramname = $con->query("SELECT programme FROM programmes  where program_id='$proramid'");
								while($rowcourse = mysqli_fetch_array($getproramname)){
						$programname=$rowcourse['programme'];
								
								}
								
$sessionadmintedid = $row['SessionAdmittedID'];
$getsessionadmited = $con->query("SELECT SessionName FROM acd_add_session  where session_id='$sessionadmintedid'");
								while($rowcourse = mysqli_fetch_array($getsessionadmited)){
						$SessionAdmitted=$rowcourse['SessionName'];
								
								}
$sessiongraduatedid = $row['SessionGraduatedID']; 
$getsessiongraduated = $con->query("SELECT SessionName FROM acd_add_session  where session_id='$sessiongraduatedid'");
								while($rowcourse = mysqli_fetch_array($getsessiongraduated)){
						$Sessiongraduated=$rowcourse['SessionName'];
								
								}	
?>

											<tr>
												<td><?php echo $row['id'];?></td>
												<td><?php echo $row['user_ID'];?></td>
                                                
												<td><?php echo $row['fullName'];?></td>
												<td><?php echo $row['address'];?></td>
                                               <td><?php $gpa=$row['city']/$row['tcc'];  echo number_format($gpa,2);?></td>
                                                
												<td><?php echo $row['gender'];?></td>
                                                <td><?php echo $row['phoneNo'];?></td>
                                                <td><?php echo $programname;?></td>
                                                <td><?php echo $SessionAdmitted;?></td>
                                            <td><?php echo $Sessiongraduated;?></td>
											
                                            </tr>
											
											<?php 
									$cnt=$cnt+1;
											 //}
												}
											 ?>
											
											
										</tbody>
									</table>
                                   																
                                                        <button type="submit" name="confirm" class="btn btn-o btn-primary">
															Confirmed
														</button>
                                                        
                                                        <button type="submit" name="continue" class="btn btn-o btn-primary">
															Continue
														</button>
                                                        <?php 
                                                        
                                                        if(isset($_POST["continue"])){
?>
<p></p><a href ="panding_application">Continue to Process </a>

    <?php
}
                                                        ?>
													</form>
                                                    
	</body>
</html>
