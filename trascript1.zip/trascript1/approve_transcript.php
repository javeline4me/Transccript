	<?php
	session_start();
	error_reporting(0);
	include('include/config.php');
	include('include/checklogin.php');
	check_login();

	$transactiondatetime = date("Y-m-d h:i:sa");
	
	$viewid = $_GET['id'];
	$viewidexplode = explode("*",$viewid);
		 $qid = $viewidexplode[0];
		$appcode = $viewidexplode[1];
		//$transcode = $viewidexplode[2];
	//updating Admin Remark


	$getusers = mysqli_query("SELECT * FROM admin_users WHERE docEmail = '".$_SESSION['login']."' ");

	$usersessiondetail = mysqli_fetch_array($getusers);

	 $userName = $usersessiondetail['FullName'];
	 
	if(isset($_POST['confim']))
			  {
	$confirmstatus = $_POST['confirmstatus'];
	$adminremark = $_POST['adminremark'];
	$sendkeys = md5($transactiondatetime);
	if($confirmstatus=="1"){
		//echo "update request_transcript set  ApproveStatus='$confirmstatus',ApproveBy='".$_SESSION['id']."',ApproveDate = '$transactiondatetime', Approval_deniedremark = 'Success'  where appNo = '$appcode'";
$query=mysqli_query($con,"update request_transcript set  ApproveStatus='$confirmstatus',ApproveBy='".$_SESSION['id']."',ApproveDate = '$transactiondatetime', Approval_deniedremark = 'Success', sendKey = '$sendkeys'   where appNo = '$appcode'");
	}else{
$query=mysqli_query($con,"update request_transcript set  ApproveStatus='$confirmstatus',ApproveBy='".$_SESSION['id']."',ApproveDate = '$transactiondatetime', Approval_deniedremark = '$adminremark'  where appNo = '$appcode'");
		
	}
	if($query){
	echo "<script>alert('Transcript was Approved successfully.');</script>";
	echo "<script>window.location.href ='pending_approval'</script>";
	}
			  }
	?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/registrasidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Pending Transcript Approval</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Pending Transcript Approval</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						

									<div class="row">
								<div class="col-md-12">
									<h5 class="over-title margin-bottom-15"> <span class="text-bold">Approve</span></h5>
									<table class="table table-hover" id="sample-table-1">
		
										<tbody>
<?php
//$qid = $_GET['id'];
//echo "select * from request_transcript t JOIN users u ON(u.user_ID=t.StudentNumber) where u.user_ID='$qid' AND t.appNo = '$appcode' ";
$sql=mysqli_query($con,"select * from request_transcript t JOIN users u ON(u.user_ID=t.StudentNumber) where u.user_ID='$qid' AND t.appNo = '$appcode' ");
$cnt=1;
$row=mysqli_fetch_array($sql);
$ifexist = mysqli_num_rows($sql);
//echo "select * from transcript_tblacademics  where StudentNumber='$qid'";
$trans = mysqli_query($con,"select * from transcript_tblacademics  where StudentNumber='$qid'");
$checktrans = mysqli_num_rows($trans);
if($checktrans>0){
$transconfirm = mysqli_query($con,"select * from users  WHERE confirmTranscript = '1' AND user_ID='$qid' ");
$checkconfirm = mysqli_num_rows($transconfirm);
if($checkconfirm>0){
	$getmessage = "Records Uploaded Confirmed";
}else{
	
	$getmessage = "<p style='color:red;'>Applicant Examination Records Available but not confirm, please contact ICT</p>";
}

}else{
	$getmessage = "<p style='color:red;'>Applicant Examination Records Not Available. Please Upload this Applicant Transcript Records for confirmation</p>";
	
}
$transconfirm = mysqli_num_rows(mysqli_query($con,"select * from transaction_details  WHERE confirm_payment = '1' AND userID='$qid' "));
if($transconfirm>0){
	
	$bursary = "Payment Confirmed";
	
}else{
	$bursary = "<p style='color:red;'>Applicant Payment Confirmation is pending, please contact Bursary</p>";
	
}
$attention = mysqli_num_rows(mysqli_query($con,"select * from request_transcript t  where u.user_ID='$qid' AND u.PaymentStatus='2'"));
								if($attention<1){
?>

											<tr>
												<th>Full Name:</th>
												<td><?php  if($ifexist>0){ echo $row['fullName'];}else{ echo "<p style='color:red;'>Applicant Not Found. Please Upload this Applicant Details</p>"; }?></td>
											</tr>

											<tr>
												<th>Check Transcript:</th>
												<td><?php if($checktrans>0){ echo "Available";}else{ echo "<p style='color:red;'>Applicant Examination Records Not Available. Please Upload this Applicant Transcript Records</p>"; }?></td>
											</tr>
											<tr>
												<th>Transcript Record Confirmation</th>
												<td><?php echo $getmessage;?></td>
											</tr>
											<tr>
												<th>Check Payment Confirmation:</th>
												<td><?php echo $bursary;?></td>
												</tr>
											
										<?php
										
										if($checktrans>0&&$checkconfirm>0&&$transconfirm>0){
											
										?>
								<form name="query" method="post">
								<tr>
												<th><input type="checkbox" name="satisfy" required></th>
												<td><?php echo "This is to confirm that every necessary information are been checked";?></td>
												</tr>
											<tr>
												<th>Approve Options</th>
												<td>
		<select  class="form-control" name="confirmstatus" onChange="this.form.submit();" required>
  <option value="">Select Option</option>
  <option value="1"<?php echo ($_POST['confirmstatus']=="1")?"selected":""?>>Approve</option>
  <option value="2"<?php echo ($_POST['confirmstatus'] == "2")?"selected":""?>>Attention</option>
 <!-- <option value="3">Three</option>-->
</select>
												
												</td>
												</tr>
								<?php if($_POST['confirmstatus']=="2"){?>
													<tr>
												<th>Place Remark</th>
												<td><textarea name="adminremark" class="form-control" required="true"></textarea></td>
												</tr>
												<tr>
													<td>&nbsp;</td>
													<td>	
														<button type="submit" class="btn btn-primary pull-left" name="confim">
														Submit <i class="fa fa-arrow-circle-right"></i>
													</button>

													</td>
												</tr>
											
											<?php } else if($_POST['confirmstatus']=="1"){?>										
												
												<tr>
												<td>&nbsp;</td>
														
												<td>
												<button type="submit" class="btn btn-primary pull-left" name="confim">
														Proceed <i class="fa fa-arrow-circle-right"></i>
													</button>
													</td>
												</tr>

												<tr>
												

											
											<?php 
											 }
											 }
											 ?>
											
											</form>												
															
											
										</tbody>
									</table>
									<?php
								}else{
								
								?>
									<div></div>
									
									<?php 
								}
								?>
								</div>
							</div>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
