<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
$transactiondatetime = date("Y-m-d h:i:sa");
$qid = $_GET['id'];
//updating Admin Remark
if(isset($_POST['confim']))
		  {
$confirmstatus = $_POST['confirmstatus'];
$adminremark = $_POST['adminremark'];
//echo "SELECT * FROM transaction_details WHERE tran_ID = '$qid' AND trans_status = 'Confirmed' AND confirm_payment = '0' ";
$pendingpayment = mysqli_num_rows(mysqli_query($con,"SELECT * FROM transaction_details WHERE tran_ID = '$qid' AND trans_status = 'Confirmed' AND confirm_payment = '0' "));
if($pendingpayment>0){
if($confirmstatus=="1"){
	//echo "update transaction_details set  confirm_payment='$confirmstatus',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime' where tran_ID='$qid'";
$query=mysqli_query($con,"update transaction_details set  confirm_payment='$confirmstatus',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime', confirmationRemark = 'Success' where tran_ID='$qid' AND trans_status = 'Confirmed'");
mysqli_query($con,"UPDATE request_transcript SET PaymentStatus='1', PaymentAcceptDate='$transactiondatetime' WHERE appNo = '$qid' ");
}else{
	$query=mysqli_query($con,"update transaction_details set  confirm_payment='$confirmstatus',usedStatus= 'Closed',confirmBy='".$_SESSION['id']."',dateConfirmed = '$transactiondatetime', confirmationRemark = '$adminremark' where tran_ID='$qid' AND trans_status = 'Confirmed' ");
	mysqli_query($con,"UPDATE request_transcript SET PaymentStatus='2', PaymentAcceptDate='$transactiondatetime', confirmationRemark='$adminremark' WHERE appNo = '$qid' ");
}
if($query){
echo "<script>alert('Admin confirmation was successfully.');</script>";
echo "<script>window.location.href ='unread-queries.php'</script>";
}
}else{
	echo "<script>alert('Sorry, you are trying to Approve incomplete transaction.');</script>";
echo "<script>window.location.href ='unread-queries.php'</script>";
}
		  }
?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Confirm Transaction</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Query Details</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						

									<div class="row">
								<div class="col-md-12">
									<h5 class="over-title margin-bottom-15">Manage <span class="text-bold">Query Details</span></h5>
									<table class="table table-hover" id="sample-table-1">
		
										<tbody>
<?php
$qid = $_GET['id'];
$sql=mysqli_query($con,"select * from transaction_details t  where t.tran_ID='$qid'");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>

											<tr>
												<th>Full Name</th>
												<td><?php echo $row['Fullname'];?></td>
											</tr>

											<tr>
												<th>Email Id</th>
												<td><?php echo $row['emailAddrerss'];?></td>
											</tr>
											<tr>
												<th>Conatact Numner</th>
												<td><?php echo $row['phnoneNumber'];?></td>
											</tr>
											<tr>
												<th>Transaction Ref./Teller No.</th>
												<td><?php echo $row['trans_ref_no'];?></td>
												</tr>
											<tr>
												<th>Amount</th>
												<td><?php echo "<span>&#8358;</span> ".number_format($row['transactionAmount'],2);?></td>
												</tr>

									
								<form name="query" method="post">
											<tr>
												<th>Confirm Option</th>
												<td>
		<select  class="form-control" name="confirmstatus" onchange="this.form.submit();" required>
  <option value="">Select Option</option>
  <option value="1"<?php echo ($_POST['confirmstatus']=="1")?"selected":""?>>Confirm</option>
  <option value="2"<?php echo ($_POST['confirmstatus'] == "2")?"selected":""?>>Denied</option>
 <!-- <option value="3">Three</option>-->
</select>
												
												</td>
												</tr>
								<?php if($_POST['confirmstatus']=="2"){?>
													<tr>
												<th>Admin Remark</th>
												<td><textarea name="adminremark" class="form-control" required="true"></textarea></td>
												</tr>
												<tr>
													<td>&nbsp;</td>
													<td>	
														<button type="submit" class="btn btn-primary pull-left" name="confim">
														Denied <i class="fa fa-arrow-circle-right"></i>
													</button>

													</td>
												</tr>
											
											<?php } else if($_POST['confirmstatus']=="1"){?>										
												
												<tr>
												<td>&nbsp;</td>
														
												<td>
												<button type="submit" class="btn btn-primary pull-left" name="confim">
														Confirm <i class="fa fa-arrow-circle-right"></i>
													</button>
													</td>
												</tr>

												<tr>
												

											
											<?php 
											 }} ?>
											
											</form>												
															
											
										</tbody>
									</table>
								</div>
							</div>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
