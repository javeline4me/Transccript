<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
$transactiondatetime = date("Y-m-d h:i:sa");
$qid = $_GET['id'];
//updating Admin Remark

?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar1.php');?>
			<div class="app-content">
				
						<?php include('include/headeralumini.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Member | Track Details</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Member</span>
									</li>
									<li class="active">
										<span>Track Details</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						

									<div class="row">
								<div class="col-md-12">
									<h5 class="over-title margin-bottom-15"> <span class="text-bold">PERSONAL DETAILS</span></h5>
									<table class="table table-hover" id="sample-table-1">
		
										<tbody>
											<?php
											
											//$sql=mysqli_query($con,"select *  from transaction_details t JOIN alumni_account u ON(t.userID=u.StudentNumber) JOIN payment_type p ON(p.id=t.entry_Type) JOIN request_transcript r ON(r.appNo=t.tran_ID) where t.userID='".$_SESSION['id']."' AND t.trans_status = 'Confirmed' ");
											$qid = $_GET['id'];
											$sql=mysqli_query($con,"select * from transaction_details t JOIN request_transcript r ON(r.appNo=t.tran_ID) JOIN acd_add_session s ON(s.session_id=r.SessionGraduated) JOIN acd_department d ON(d.deptcode=r.deptID) JOIN courselist c ON(c.coscode=r.ProgramID) where t.tran_ID='$qid'");
											//$sql=mysqli_query($con,"select * from transaction_details t JOIN request_transcript r ON(r.appNo=t.tran_ID) where t.tran_ID='$qid'");
											$cnt=1;
											$checksql=mysqli_query($con,"select * from  request_transcript WHERE AppStatus=0");
											$myrowcount = mysqli_num_rows($checksql);
											
											$row=mysqli_fetch_array($sql);
											//while($row=mysqli_fetch_array($sql))
											//{
												if($myrowcount>0){
											?>
											<tr>
											<th colspan="2"><h3 style="color:red">Sorry, You have nothing to track becouse your application is pending</h3><a href="apply">Click here to apply</a></th>
											
											</tr>
											<?php
												}else{
												
												?>
											<tr>
												<th>Full Name</th>
												<td><?php echo $row['Fullname'];?></td>
											</tr>

											<tr>
												<th>Email Id</th>
												<td><?php echo $row['emailAddrerss'];?></td>
											</tr>
											<tr>
												<th>Conatact Numner</th>
												<td><?php echo $row['phnoneNumber'];?></td>
											</tr>
											<tr>
												<th>Transaction Ref./Teller No.</th>
												<td><?php echo $row['trans_ref_no'];?></td>
												</tr>
											<tr>
												<th>Amount</th>
												<td><?php echo "<span>&#8358;</span> ".number_format($row['transactionAmount'],2);?></td>
												</tr>
												<tr>
												<th colspan="2"><h5>TRACKING DETAILS</h5></th>
												
												</tr>
												<tr>
												<th>Received</th>
												<td><?php echo ($row['ReceivedStatus']!=0)?"Well Received ".$row['ReceivedDate']:"Pending";?></td>
												</tr>
												<tr>
												<th>Send</th>
												<td><?php echo ($row['SendStatus']!=0)?"Well Sent ".$row['SendDate']:"Pending";?></td>
												</tr>
												<tr>
												<th>Registrar's Approval</th>
												<td><?php echo ($row['ApproveStatus']!=0)?"Approved ".$row['ApproveDate']:"Pending";?></td>
												</tr>
												
													<tr>
												<th>Exam Officer Initiate Process</th>
												<td><?php echo ($row['StartPrecessStatus']!=0)?"Processed ".$row['StartProcessDate']:"Pending";?></td>
											</tr>
											<tr>
												<th>Payment Confirmation</th>
												<td><?php echo ($row['PaymentStatus']!=0)?"Your Payment was Confirmed on ".$row['PaymentAcceptDate']:"Pending"?></td>
											</tr>
											<tr>
												<th>Application Status</th>
												<td><?php echo ($row['AppStatus']!=1)?"Pending":"Submitted"." on ".$row['DateApp'];?></td>
											</tr>
											<?php
												}
												
												?>
										</tbody>
									</table>
								</div>
							</div>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
