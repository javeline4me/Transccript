<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();


if(isset($_GET['del']))
		  {
		          mysqli_query($con,"delete from doctors where id = '".$_GET['id']."'");
                  $_SESSION['msg']="data deleted !!";
		  }
?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
					
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Admin | Confirm Result</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Admin</span>
									</li>
									<li class="active">
										<span>Confirm Result</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
						
								

								<p style="color:red;"><?php echo htmlentities($_SESSION['msg']);?>
								<?php echo htmlentities($_SESSION['msg']="");?></p>	
													<div class="rows">
													<div class="col-md-6">
													<form role="form" name="dcotorspcl" method="post" >
														<div class="form-group">
															<label for="exampleInputEmail1">
																Course of Study
															</label>
							<select name="course" class="form-control"   required>
							<option value=""> Select Course </option>
								<?php
								$getcourse = $con->query("SELECT * FROM courselist  order by cosname ASC");
								while($rowcourse = mysqli_fetch_array($getcourse)){
								?>
								<option value="<?php echo $rowcourse['coscode']?>"><?php echo $rowcourse['cosname']?></option>
								<?php
								}
								?>
							</select>
														</div>
                                                        
                                                        
                                                        <div class="form-group">
															<label for="exampleInputEmail1">
																Session
															</label>
							<select name="session" class="form-control"   required>
							<option value=""> Select Session </option>
								<?php
								$getsession = $con->query("SELECT * FROM acd_add_session  order by SessionName ASC");
								while($rowsession = mysqli_fetch_array($getsession)){
								?>
								<option value="<?php echo $rowsession['session_id']?>"><?php echo $rowsession['SessionName']?></option>
								<?php
								}
								?>
							</select>
														</div>
                                                        
                                                        
                                                      
                                                        
                                                        
                                             <button type="submit" name="submit" class="btn btn-o btn-primary">
															Submit
														</button>
													</form>   
													</div>
													
													<div class="col-md-6">
													
													 <div class="form-group">
															<label for="exampleInputEmail1">
																Semester
															</label>
							<select name="semester" class="form-control"   required>
							<option value=""> Select Semester </option>
								<?php
								$getsemester = $con->query("SELECT * FROM acd_semester  order by semestername ASC");
								while($rowsemester = mysqli_fetch_array($getsemester)){
								?>
								<option value="<?php echo $rowsemester['semestercode']?>"><?php echo $rowsemester['semestername']?></option>
								<?php
								}
								?>
							</select>
														</div>
                                                         
                                                     <div class="form-group">
															<label for="exampleInputEmail1">
																Level
															</label>
							<select name="level" class="form-control"   required>
							<option value=""> Select Level </option>
								<?php
								$getlevel = $con->query("SELECT * FROM acd_avalaiblelevel  order by levelcode ASC");
								while($rowlevel = mysqli_fetch_array($getlevel)){
								?>
								<option value="<?php echo $rowlevel['id']?>"><?php echo $rowlevel['levelcode']?></option>
								<?php
								}
								?>
							</select>
														</div> 
													</div>
													</div>
													<br/> <br/>
													
										<?php 


										if(isset($_POST["course"])){
										$course=$_POST["course"];
										$session=$_POST["session"];
										$semester=$_POST["semester"];
										$level=$_POST["level"];
										?>

									<div class="row">
								<div class="col-md-12 table-responsive">
									<h5 class="over-title margin-bottom-15">Summary Result For: <span class="text-bold">Qualified Members</span></h5>
									<table class="table table-hover" id="table_id">
										<thead>
											<tr>
												<th class="center">Sno</th>
												<th>Mat No</th>
												<th class="hidden-xs">Name </th>
												<th>TCC </th>
												<th>TCE </th>
												<th>TPE</th>
                                                <th>GPA</th>
												<th>PTCC </th>
												<th>PTCE</th>
                                                <th>PTPE</th>
                                                <th>PGPA</th>
                                                <th>CCC</th>
                                                <th>CCE</th>
                                                <th>CPE</th>
                                                <th>CGPA</th>
												
											</tr>
										</thead>
										<tbody>
<?php

$sql = mysqli_query($con,"select * from transcript_tmpsenate where programid='$course' and sessionid='$session' and semesterid='$semester' and levelid='$level'");
$cnt=1;
while($row=mysqli_fetch_assoc($sql))
{
	
?>

											<tr>
												<td class="center"><?php echo $cnt;?></td>
												<td class="hidden-xs"><?php echo $row['studentnumber'];?></td>
												<td><?php echo $row['fullname'];?></td>
												<td><?php echo $row['tcc'];?></td>
												<td><?php echo $row['tce'];?></td>
												<td><?php echo $row['tpe'];?></td>
                                               <td><?php $gpa=$row['tpe']/$row['tcc'];  echo number_format($gpa,2);?></td>
                                                
												<td><?php echo $row['ptcc'];?></td>
                                                <td><?php echo $row['ptce'];?></td>
                                                <td><?php echo $row['ptpe'];?></td>
                                          <td><?php $pgpa=(intval($row['ptpe']/$row['ptcc']));  echo number_format($pgpa,2);?></td>
                                                <td><?php echo $row['ccc'];?></td>
                                                <td><?php echo $row['cce'];?></td>
                                                <td><?php echo $row['cpe'];?></td>
                                            <td><?php $cgpa=$row['cpe']/$row['ccc'];  echo number_format($cgpa,2);?></td>
												
											
                                            </tr>
											
											<?php 
									$cnt=$cnt+1;
											 //}
												}
											 ?>
											
											
										</tbody>
									</table>
								</div>
							</div>
                            <?php } ?>
								</div>
							</div>
						</div>
						<!-- end: BASIC EXAMPLE -->
						<!-- end: SELECT BOXES -->
						
					</div>
				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<script src="vendor/DataTables/jquery.dataTables.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		
  

		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
			
			$(document).ready( function () {
    $('#table_id').DataTable();
			} );
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
