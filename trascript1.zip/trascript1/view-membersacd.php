<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
if(isset($_POST['submit']))
  {
    
    $vid=$_GET['viewid'];
    $bp=$_POST['bp'];
    $bs=$_POST['bs'];
    $weight=$_POST['weight'];
    $temp=$_POST['temp'];
   $pres=$_POST['pres'];
   
 
      $query.=mysqli_query($con, "insert   tblmedicalhistory(PatientID,BloodPressure,BloodSugar,Weight,Temperature,MedicalPres)value('$vid','$bp','$bs','$weight','$temp','$pres')");
    if ($query) {
    echo '<script>alert("Medicle history has been added.")</script>';
    echo "<script>window.location.href ='manage-patient.php'</script>";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  
}

?>
<!DOCTYPE html>
<html lang="en">
	<?php 
	include("include/headerscript.html");
	?>
	<body>
		<div id="app">		
<?php include('include/academicsidebar.php');?>
<div class="app-content">
<?php include('include/header.php');?>
<div class="main-content" >
<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
<section id="page-title">
<div class="row">
<div class="col-sm-8">
<h1 class="mainTitle">Admin | Manage Memebers</h1>
</div>
<ol class="breadcrumb">
<li>
<span>Admin</span>
</li>
<li class="active">
<span>Manage Patients</span>
</li>
</ol>
</div>
</section>
<div class="container-fluid container-fullw bg-white">
<div class="row">
<div class="col-md-12">
<h5 class="over-title margin-bottom-15">Manage <span class="text-bold">Memebers</span></h5>
<?php
                               $vid=$_GET['viewid'];
                               $ret=mysqli_query($con,"select * from users u join courselist t ON(u.ProgramID=t.coscode) join acd_avalaiblelevel v ON(v.id=u.graduatedLevelID) join acd_department d ON(d.deptcode=u.deptID) join faculties f ON(d.faccode=f.faccode) join acd_add_session s ON(s.session_id=u.SessionGraduatedID) where u.user_ID='$vid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
                               ?>
<table border="1" class="table table-bordered">
 <tr align="center">
<td colspan="4" style="font-size:20px;color:blue">
 Memebers Details</td></tr>

    <tr>
    <th scope>Memebers Name</th>
    <td><?php  echo $row['fullName'];?></td>
    <th scope>Memebers Email</th>
    <td><?php  echo $row['email'];?></td>
  </tr>
  <tr>
    <th scope>Memebers Mobile Number</th>
    <td><?php  echo $row['phoneNo'];?></td>
    <th>Memebers Address</th>
    <td><?php  echo $row['address'];?></td>
  </tr>
    <tr>
    <th>Memebers Gender</th>
    <td><?php  echo $row['gender'];?></td>
    <th>Registration Date</th>
    <td><?php  echo $row['regDate'];?></td>
  </tr>
  
  <!--
  <tr>
    
    <th>Any Memebers History(if any)</th>
    <td><?php  //echo $row['PatientMedhis'];?></td>
     <th>Memebers Reg Date</th>
    <td><?php  //echo $row['CreationDate'];?></td>
  </tr>
 -->

</table>
<?php  

$ret1=mysqli_query($con,"select count(*) AS total1 from referrers_details  where referrerID='$vid'");
$ret2=mysqli_query($con,"select count(*) AS total2 from first_control_referrer  where masterReferrerID='$vid'");
$ret3=mysqli_query($con,"select count(*) AS total3 from secon_control_referrer  where masterReferrerID='$vid'");



 ?>
<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
  <tr align="center">
   <th colspan="8" >Memebers Details</th> 
  </tr>
  <tr>
    <th>#</th>
<th>Matric. No</th>
<th>Program</th>
<th>Level</th>
<th>Department</th>
<th>Session</th>
<th>College</th>
</tr>
<?php  
$row1=mysqli_fetch_array($ret1); 
$row2=mysqli_fetch_array($ret2); 
$row3=mysqli_fetch_array($ret3); 
  ?>
<tr>
  <td><?php echo $cnt;?></td>
 <td><?php  echo $row['user_ID'];?></td>
 <td><?php echo $row['cosname'];?></td>
 <td><?php  echo $row['levelcode'];?></td> 
  <td><?php  echo $row['deptname'];?></td>
  <td><?php  echo $row['SessionName'];?></td>
  <td><?php   echo $row['facname'];?></td> 
</tr>
<?php }?>
</table>
                          
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
