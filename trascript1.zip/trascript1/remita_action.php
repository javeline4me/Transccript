<?php
session_start();
include('include/config.php');
include('include/checklogin.php');
$TranId = $_GET['TranId'];

$read_students = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs WHERE tran_ID = '$TranId' AND trans_status = '0'"));
//if ($_POST["txtaction"]='login')
//{
	$action_url = "";
	$msg = "";
	 $transid = $_GET['TranId'];//$_SESSION['transid'] ;
	//$invoicestr = $_SESSION['invoiceids'];
	 
	 $paytype = $read_students['entry_Type'];
	 $toptional = $read_students['transactionAmount'];
	 
//$read_students = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM transaction_details_logs WHERE userID = '' AND trans_status = '0' "));
$SurName = $read_students['Fullname'];

$RegistrationNo = $read_students['userID'];
$PhoneNO = $read_students['phnoneNumber'];
$fullName = $SurName;

$emailaddress =  $read_students['emailAddrerss'];
$telephone =  $read_students['phnoneNumber'];
	
	 /* 
	if(isset($_POST['search'])){
		
			//$checkbox = $invoicestr;
			//$paytype = $_POST['payType'];
			//$transid = $_POST['transid'];  
			$transdate = date("Y-m-d");		
			$time = date("g:i A");	
			//$toptional = $_POST['toptional'];	
		//$invoicestr = implode(',', $checkbox);
		
		$checkbox = explode(',', $invoicestr);
		
        for($i=0;$i<count($checkbox);$i++){
        $check_id = $checkbox[$i];
	 $checkid = $con->query("select * from pay_temp_invice_trans where personalInvoiceId = '$check_id'  ")->rowCount(); 
	  if($checkid<1){
		  
	 $addme = $con->query("INSERT INTO pay_temp_invice_trans(StudentNumber,personalInvoiceId,confirmstatus,transid) VALUES('$userid','$check_id','0','$transid')");
	  }
	   }
	  $checkme = $con->query("select * from pay_main_transaction where trainId = '$transid'  ")->rowCount(); 
	  if($checkme<1){
	$insert = $con->query("INSERT INTO pay_main_transaction(trainId,StudentNumber,Fullname,referenceCod,confirmstatus,transactiondate,transactionTime,feeType,Amount,paidBy,RRR) VALUES('$transid','$userid','$fullName','0','0','$transdate','$time','$paytype','$toptional','$userid','0')");
	
	}
	}	*/	
	 $preventme = mysqli_num_rows(mysqli_query($con,"select * from transaction_details_logs where tran_ID = '$transid'  "));   
		//require_once('functions.php');
		$t= $transid;
		
		$opt=1;
				
		$totalAmount = $_POST['amt'];
		if($totalAmount==""){
			header("location:makepayment");
		}
		$email= $_POST['email']; 
		
		$tel= $_POST['tel'];
		//$pos = $_POST['pos']; 		
		
		$des = $_POST['des'];
		
		$custname = $_POST['cust_name']; 
		$std = $_POST['cust_id'];
		
	//$tech =100; $itemid1="UAM".$t; $itemid2="SMT".$t;
		$tech = 0.00; $itemid1="UAM".$t; $itemid2="SMT".$t;
		
	if($preventme>0){
		
	$cl_data =  mysqli_num_rows(mysqli_query($con,"select * from transaction_details_logs where tran_ID = '$TranId' AND trans_status = '0'"));

if ($cl_data>0)
	{
		
		include 'remita_constants.php'; 
	//include 'remita_constants_demo.php'; 	
////////////////////////////////////////////////////////////////////////////////////////////

		//*******This is where the deductions are made /$uam = $totalAmount-$tech; $timesammp=DATE("dmyHis"); $orderID = $t; $payerName = $custname;
	 $uam = $totalAmount; $timesammp=DATE("dmyHis"); $orderID = $transid; $payerName = $custname;
		$payerEmail = $email; $payerPhone = $tel;
	
//$responseurl = PATH . "/sample-receipt-page.php";
$merchant= MERCHANTID;
$responseurl ="localhost/replyrespons.php";
//$responseurl ="https://fees.uam.edu.ng/getresp/replyrespons.php";
$hash_string = MERCHANTID . SERVICETYPEID . $orderID . $totalAmount . $responseurl . APIKEY;

$hash = hash('sha512', $hash_string); 
$beneficiaryName="University of Agriculture Makurdi"; $beneficiaryName2="Skilled Minds Tech"; 
$beneficiaryAccount="0180474861013"; $beneficiaryAccount2="1018593511"; 

$bankCode="000"; $bankCode2="033"; $beneficiaryAmount =$uam; $beneficiaryAmount2 =$tech; //$beneficiaryAmount3 ="50";
$deductFeeFrom=1; $deductFeeFrom2=0; //$deductFeeFrom3=0;
//The JSON data.
$content = '{"merchantId":"'. MERCHANTID
.'"'.',"serviceTypeId":"'.SERVICETYPEID
.'"'.",".'"totalAmount":"'.$totalAmount
.'","hash":"'. $hash
.'"'.',"orderId":"'.$orderID
.'"'.",".'"responseurl":"'.$responseurl
.'","payerName":"'. $custname
.'"'.',"payerEmail":"'.$payerEmail
.'"'.",".'"payerPhone":"'.$payerPhone
.'","lineItems":[
{"lineItemsId":"'.$itemid1.'","beneficiaryName":"'.$beneficiaryName.'","beneficiaryAccount":"'.$beneficiaryAccount.'","bankCode":"'.$bankCode.'","beneficiaryAmount":"'.$beneficiaryAmount.'","deductFeeFrom":"'.$deductFeeFrom.'"},
{"lineItemsId":"'.$itemid2.'","beneficiaryName":"'.$beneficiaryName2.'","beneficiaryAccount":"'.$beneficiaryAccount2.'","bankCode":"'.$bankCode2.'","beneficiaryAmount":"'.$beneficiaryAmount2.'","deductFeeFrom":"'.$deductFeeFrom2.'"}
]}';
	
/*$curl = curl_init(GATEWAYURL);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER,
array("Content-type: application/json"));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
$json_response = curl_exec($curl);
$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
$jsonData = substr($json_response, 6, -1);
$response = json_decode($jsonData, true);
$statuscode = $response['statuscode'];
$statusMsg = $response['status'];*/

		$curl = curl_init(GATEWAYURL);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER,
array("Content-type: application/json"));
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); 
$json_response = curl_exec($curl);

$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
$jsonData = substr($json_response, 6, -1);
$response = json_decode($jsonData, true);

$statuscode = $response['statuscode'];
$statusMsg = $response['status'];
//echo "try me here Coode ".$statuscode." Mgs ".$statusMsg;
	if($statuscode=='025'){
		$rrr = trim($response['RRR']);
		//if ($opt !=60) {$opt=1;}
		$val1 = mt_rand(); $val2 = rand();$val3 = rand(); 	
		$pin = "$val3$val1$val2";  $pin = mb_substr($pin,0,14);
		
		$cl_data =$con->query("update transaction_details_logs set  trans_ref_no= '$rrr',RRRStatus = '$statuscode',RRRMessage = '$statusMsg' WHERE tran_ID= '$transid'");
		$msg = "If you cannot print your invoice, copy your RRR and proceed with payment";
		$new_hash_string = MERCHANTID . $rrr . APIKEY;
		
		$new_hash = hash('sha512', $new_hash_string);
		$link="print_rrr?txn=$orderID"; echo "<script>page='$link'</script>";
	}
 }
//}
//echo "select trans_ref_no from transaction_details_logs where tran_ID= '$transid'";
$getrr =  mysqli_fetch_array(mysqli_query($con,"select trans_ref_no from transaction_details_logs where tran_ID= '$transid'"));
$rrr = !empty($getrr['trans_ref_no'])?$getrr['trans_ref_no']:"";

if ($rrr=="0")
{
	$msg ="<font face='Verdana, Arial, Helvetica, sans-serif' color='#FF0000' size='-1' >Unable to place order for payment. Kindly initiate another request </font>'";
	$bank =""; $card="";
}
else
{
		$bank ='<img src="images/bank.png" style="cursor:pointer" width="270" height="65" onClick="return pt(page)">'; 
		$card='<img src="images/online.png" style="cursor:pointer" onClick="return view_client()" width="270" height="65">';
}
}

?>
<html lang="en">
    <head>
         <?php include('include/headerscript.html'); ?>
    </head>
    <body class="top-navbar-fixed">
        <div class="main-wrapper">

            <!-- ========== TOP NAVBAR ========== -->
  <?php include('include/headeralumini.php');?> 
            <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
            <div class="content-wrapper">
                <div class="content-container">

                    <!-- ========== LEFT SIDEBAR ========== -->
                   <?php include('include/sidebar1.php');?>  
                    <!-- /.left-sidebar -->

                    <div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						
                        <div class="container-fluid">
                           
                        <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                           
                                            <div class="panel-body">
							
							<div class="bs-exp">
												
											

<center>
<div class="card">
							  <div class="row">
							  <div class="col-md-2">&nbsp;</div>
							  <div class="col-md-8">
								<div class="row space-16">&nbsp;</div>
								<div class="row">
								  <div class="col-sm-12">
									<div class="thumbnail">
									  <div class="caption">
<form name="SubmitRemitaForm" enctype="application/x-www-form-urlencoded" method="post" action="https://login.remita.net/remita/ecomm/finalize.reg">
<div class="table-responsive-md">
  <table width="744" border="0" class="table">
    
	<!--  <table width="716" height="555" border="0" style="background-repeat:no-repeat; background-image:url(images/interswitch1.png)">-->
        
              <tr>
                <td height="20" colspan="4">
				<input type="hidden" name="txtaction" id="txtaction">
                <input id="merchantId" name="merchantId" value="<?php echo $merchant; ?>" type="hidden"/>
				<input id="rrr" name="rrr" value="<?php echo $rrr; ?>" type="hidden"/>
				<input id="responseurl" name="responseurl" value="<?php echo $responseurl; ?>" type="hidden"/>
				<input id="paymenttype" name="paymenttype" value="VERVE" type="hidden"/>                
				<input id="hash" name="hash" value="<?php echo $new_hash; ?>" type="hidden"/>

                </td>
              </tr>
              <tr>
                <td height="40" colspan="4">To make payment in the bank or use use your internet banking platform, click on '<strong>Bank Branch/Internet Banking</strong>' or copy your RRR number to enable you pay in the bank.</td>
              </tr>
              <tr>
                <td height="36" colspan="4">If you want to continue payment online, click in the 'Continue Payment Online' button and follow the instructions</td>
              </tr>
              <tr>
                <td height="20" colspan="4"><strong>Note that the total amount includes transaction charges.</strong></td>
                </tr>
              <tr>
                <td height="31" ><strong>RRR</strong>:</td>
                <td colspan="3" ><?php echo $rrr; 	?></td>
              </tr>
              <tr>
                <td width="290" height="31" ><strong>Total Amount:</strong></td>
                <td colspan="3" ><?php echo number_format($totalAmount,2); ?></td>
                </tr>
              <tr>
                <td height="24" ><strong>Reg. Number:</strong></td>
                <td colspan="3" ><?php echo strtoupper($std); ?></td>
              </tr>
              <tr>
                <td height="26" ><strong>Name:</strong></td>
                <td colspan="3" ><?php echo $custname;//" RESP CODE ".$statuscode; ?></td>
              </tr>

                 <tr>
                   <td height="25" colspan="4" ><?php echo $msg; ?>
                    <input type="hidden" name="txth" id="txth"></td>
                 </tr>
              <tr>
                <td height="30" colspan="4" align="center">&nbsp;</td>
                </tr>
              <tr>
                <td height="21" align="center"><?php echo $bank; ?></td>
                <td height="21" align="center"></td>
                <td width="40" height="21" align="center"></td>
                <td width="294" height="21" align="center"><?php echo $card; ?></td>
              </tr>
            
  </table>
  </div>
  
  </div>
          <div class="caption card-footer text-center">
             <div class="position-relative">
              <img src="images/RMT_Card.PNG" style="width:572px;height:72px;" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-2">&nbsp;</div>
  </div>
</div>
														
														</div>
</form>

</center>
 </div>
            <!-- /.content-wrapper -->
        </div>
		   </div>
                </div>
                <!-- /.content-container -->
		 <?php include('includes/htnlFooter.html'); ?>
</body>
</html>

<script language ="javascript">
function view_client() {
	document.SubmitRemitaForm.submit();
}

function pt(page)
{
	//window.close();
	window.open(page, "CtrlWindow", "width=1200,height=800,toolbar=no,menubar=yes,location=no,scrollbars=no,resize=no")
	
	}
</script>
